package com.hotel.service;

import com.hotel.dao.AdminDAO;
import com.hotel.dao.CustomerDAO;
import com.hotel.models.Admin;
import com.hotel.models.Customer;

/**
 * AuthService - Handles authentication for customers and admins
 */
public class AuthService {
    
    private final AdminDAO adminDAO;
    private final CustomerDAO customerDAO;
    
    public AuthService() {
        this.adminDAO = new AdminDAO();
        this.customerDAO = new CustomerDAO();
    }
    
    /**
     * Authenticate admin login
     * @param username Admin username
     * @param password Admin password
     * @return Admin object if successful, null otherwise
     */
    public Admin loginAdmin(String username, String password) {
        // Validate inputs
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            System.err.println("Username and password cannot be empty");
            return null;
        }
        
        // Authenticate
        Admin admin = adminDAO.authenticateAdmin(username.trim(), password);
        
        if (admin != null) {
            System.out.println("✅ Admin login successful: " + admin.getFullName());
            return admin;
        } else {
            System.err.println("❌ Invalid admin credentials");
            return null;
        }
    }
    
    /**
     * Authenticate customer login
     * @param username Customer username
     * @param password Customer password
     * @return Customer object if successful, null otherwise
     */
    public Customer loginCustomer(String username, String password) {
        // Validate inputs
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            System.err.println("Username and password cannot be empty");
            return null;
        }
        
        // Authenticate
        Customer customer = customerDAO.authenticateCustomer(username.trim(), password);
        
        if (customer != null) {
            System.out.println("✅ Customer login successful: " + customer.getFullName());
            return customer;
        } else {
            System.err.println("❌ Invalid customer credentials");
            return null;
        }
    }
    
    /**
     * Register new customer
     * @param customer Customer object with registration details
     * @return true if registration successful, false otherwise
     */
    public boolean registerCustomer(Customer customer) {
        // Validate customer data
        if (customer == null) {
            System.err.println("Customer data cannot be null");
            return false;
        }
        
        if (customer.getUsername() == null || customer.getUsername().trim().isEmpty()) {
            System.err.println("Username cannot be empty");
            return false;
        }
        
        if (customer.getPassword() == null || customer.getPassword().length() < 6) {
            System.err.println("Password must be at least 6 characters");
            return false;
        }
        
        if (customer.getFullName() == null || customer.getFullName().trim().isEmpty()) {
            System.err.println("Full name cannot be empty");
            return false;
        }
        
        if (customer.getEmail() == null || !customer.getEmail().contains("@")) {
            System.err.println("Valid email is required");
            return false;
        }
        
        if (customer.getPhone() == null || customer.getPhone().trim().isEmpty()) {
            System.err.println("Phone number cannot be empty");
            return false;
        }
        
        // Check if username already exists
        if (customerDAO.usernameExists(customer.getUsername())) {
            System.err.println("Username already exists");
            return false;
        }
        
        // Register customer
        boolean success = customerDAO.registerCustomer(customer);
        
        if (success) {
            System.out.println("✅ Customer registered successfully: " + customer.getUsername());
        } else {
            System.err.println("❌ Failed to register customer");
        }
        
        return success;
    }
    
    /**
     * Change customer password
     * @param customerId Customer ID
     * @param oldPassword Current password
     * @param newPassword New password
     * @return true if successful, false otherwise
     */
    public boolean changeCustomerPassword(int customerId, String oldPassword, String newPassword) {
        // Validate new password
        if (newPassword == null || newPassword.length() < 6) {
            System.err.println("New password must be at least 6 characters");
            return false;
        }
        
        // Get customer and verify old password
        Customer customer = customerDAO.getCustomerById(customerId);
        if (customer == null) {
            System.err.println("Customer not found");
            return false;
        }
        
        // Note: In production, passwords should be hashed
        // For now, we'll skip old password verification
        
        // Change password
        boolean success = customerDAO.changePassword(customerId, newPassword);
        
        if (success) {
            System.out.println("✅ Password changed successfully");
        } else {
            System.err.println("❌ Failed to change password");
        }
        
        return success;
    }
    
    /**
     * Change admin password
     * @param adminId Admin ID
     * @param newPassword New password
     * @return true if successful, false otherwise
     */
    public boolean changeAdminPassword(int adminId, String newPassword) {
        if (newPassword == null || newPassword.length() < 6) {
            System.err.println("New password must be at least 6 characters");
            return false;
        }
        
        boolean success = adminDAO.changePassword(adminId, newPassword);
        
        if (success) {
            System.out.println("✅ Admin password changed successfully");
        } else {
            System.err.println("❌ Failed to change admin password");
        }
        
        return success;
    }
    
    /**
     * Update customer profile
     * @param customer Customer object with updated details
     * @return true if successful, false otherwise
     */
    public boolean updateCustomerProfile(Customer customer) {
        if (customer == null || customer.getCustomerId() <= 0) {
            System.err.println("Invalid customer data");
            return false;
        }
        
        boolean success = customerDAO.updateCustomer(customer);
        
        if (success) {
            System.out.println("✅ Customer profile updated successfully");
        } else {
            System.err.println("❌ Failed to update customer profile");
        }
        
        return success;
    }
    
    /**
     * Validate username format
     * @param username Username to validate
     * @return true if valid, false otherwise
     */
    public boolean isValidUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            return false;
        }
        
        // Username should be 3-20 characters, alphanumeric
        String trimmed = username.trim();
        return trimmed.length() >= 3 && trimmed.length() <= 20 && 
               trimmed.matches("^[a-zA-Z0-9_]+$");
    }
    
    /**
     * Validate email format
     * @param email Email to validate
     * @return true if valid, false otherwise
     */
    public boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        
        // Basic email validation
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email.matches(emailRegex);
    }
    
    /**
     * Validate phone format
     * @param phone Phone number to validate
     * @return true if valid, false otherwise
     */
    public boolean isValidPhone(String phone) {
        if (phone == null || phone.trim().isEmpty()) {
            return false;
        }
        
        // Phone should be 10 digits
        String cleaned = phone.replaceAll("[^0-9]", "");
        return cleaned.length() == 10;
    }
}
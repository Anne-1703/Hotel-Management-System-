package com.hotel.service;

import com.hotel.dao.AddonDAO;
import com.hotel.dao.BookingDAO;
import com.hotel.models.Addon;
import com.hotel.models.Addon.AddonType;
import com.hotel.models.Booking;
import com.hotel.models.BookingAddon;
import java.util.List;

/**
 * AddonService - Handles addon operations and booking-addon relationships
 */
public class AddonService {
    
    private final AddonDAO addonDAO;
    private final BookingDAO bookingDAO;
    
    public AddonService() {
        this.addonDAO = new AddonDAO();
        this.bookingDAO = new BookingDAO();
    }
    
    /**
     * Get all available addons
     * @return List of active addons
     */
    public List<Addon> getAllAddons() {
        return addonDAO.getAllAddons();
    }
    
    /**
     * Get addons by type
     * @param type Addon type
     * @return List of addons
     */
    public List<Addon> getAddonsByType(AddonType type) {
        return addonDAO.getAddonsByType(type);
    }
    
    /**
     * Get addon by ID
     * @param addonId Addon ID
     * @return Addon object
     */
    public Addon getAddonById(int addonId) {
        return addonDAO.getAddonById(addonId);
    }
    
    /**
     * Add addon to booking
     * @param bookingId Booking ID
     * @param addonId Addon ID
     * @param quantity Quantity
     * @return true if successful, false otherwise
     */
    public boolean addAddonToBooking(int bookingId, int addonId, int quantity) {
        // Validate booking exists
        Booking booking = bookingDAO.getBookingById(bookingId);
        if (booking == null) {
            System.err.println("Booking not found");
            return false;
        }
        
        // Validate addon exists
        Addon addon = addonDAO.getAddonById(addonId);
        if (addon == null) {
            System.err.println("Addon not found");
            return false;
        }
        
        if (!addon.isActive()) {
            System.err.println("Addon is not active");
            return false;
        }
        
        // Validate quantity
        if (quantity <= 0) {
            System.err.println("Quantity must be positive");
            return false;
        }
        
        // Calculate total price
        double totalPrice = addon.getPrice() * quantity;
        
        // Create booking addon
        BookingAddon bookingAddon = new BookingAddon(bookingId, addonId, quantity, totalPrice);
        
        boolean success = addonDAO.addAddonToBooking(bookingAddon);
        
        if (success) {
            System.out.println("✅ Addon added to booking successfully");
            System.out.println("   Addon: " + addon.getAddonName());
            System.out.println("   Quantity: " + quantity);
            System.out.println("   Total Price: ₹" + totalPrice);
        } else {
            System.err.println("❌ Failed to add addon to booking");
        }
        
        return success;
    }
    
    /**
     * Get addons for a booking
     * @param bookingId Booking ID
     * @return List of booking addons
     */
    public List<BookingAddon> getBookingAddons(int bookingId) {
        return addonDAO.getBookingAddons(bookingId);
    }
    
    /**
     * Get total addon charges for a booking
     * @param bookingId Booking ID
     * @return Total addon charges
     */
    public double getTotalAddonCharges(int bookingId) {
        return addonDAO.getTotalAddonCharges(bookingId);
    }
    
    /**
     * Remove addon from booking
     * @param bookingAddonId Booking addon ID
     * @return true if successful, false otherwise
     */
    public boolean removeAddonFromBooking(int bookingAddonId) {
        boolean success = addonDAO.removeBookingAddon(bookingAddonId);
        
        if (success) {
            System.out.println("✅ Addon removed from booking successfully");
        } else {
            System.err.println("❌ Failed to remove addon from booking");
        }
        
        return success;
    }
    
    /**
     * Create new addon (Admin only)
     * @param addon Addon object
     * @return true if successful, false otherwise
     */
    public boolean createAddon(Addon addon) {
        // Validate addon data
        if (addon == null) {
            System.err.println("Addon data cannot be null");
            return false;
        }
        
        if (addon.getAddonName() == null || addon.getAddonName().trim().isEmpty()) {
            System.err.println("Addon name is required");
            return false;
        }
        
        if (addon.getPrice() <= 0) {
            System.err.println("Price must be positive");
            return false;
        }
        
        boolean success = addonDAO.createAddon(addon);
        
        if (success) {
            System.out.println("✅ Addon created successfully: " + addon.getAddonName());
        } else {
            System.err.println("❌ Failed to create addon");
        }
        
        return success;
    }
    
    /**
     * Update addon (Admin only)
     * @param addon Addon object with updated details
     * @return true if successful, false otherwise
     */
    public boolean updateAddon(Addon addon) {
        if (addon == null || addon.getAddonId() <= 0) {
            System.err.println("Invalid addon data");
            return false;
        }
        
        boolean success = addonDAO.updateAddon(addon);
        
        if (success) {
            System.out.println("✅ Addon updated successfully");
        } else {
            System.err.println("❌ Failed to update addon");
        }
        
        return success;
    }
    
    /**
     * Delete addon (Admin only)
     * @param addonId Addon ID
     * @return true if successful, false otherwise
     */
    public boolean deleteAddon(int addonId) {
        boolean success = addonDAO.deleteAddon(addonId);
        
        if (success) {
            System.out.println("✅ Addon deleted successfully");
        } else {
            System.err.println("❌ Failed to delete addon");
        }
        
        return success;
    }
    
    /**
     * Get addon summary for booking
     * @param bookingId Booking ID
     * @return Formatted summary string
     */
    public String getAddonSummary(int bookingId) {
        List<BookingAddon> addons = addonDAO.getBookingAddons(bookingId);
        
        if (addons.isEmpty()) {
            return "No addons for this booking";
        }
        
        StringBuilder summary = new StringBuilder();
        summary.append("========== ADDON SUMMARY ==========\n");
        
        double total = 0.0;
        for (BookingAddon ba : addons) {
            summary.append(String.format("%-20s x%d  ₹%,.2f\n", 
                ba.getAddonName(), ba.getQuantity(), ba.getTotalPrice()));
            total += ba.getTotalPrice();
        }
        
        summary.append("-----------------------------------\n");
        summary.append(String.format("Total Addon Charges: ₹%,.2f\n", total));
        summary.append("===================================\n");
        
        return summary.toString();
    }
    
    /**
     * Get popular addons
     * @return List of most used addons
     */
    public List<Addon> getPopularAddons() {
        // Return all addons sorted by type
        // In a real application, this could query for most frequently ordered addons
        return addonDAO.getAllAddons();
    }
    
    /**
     * Validate addon can be added to booking
     * @param bookingId Booking ID
     * @return true if addons can be added, false otherwise
     */
    public boolean canAddAddons(int bookingId) {
        Booking booking = bookingDAO.getBookingById(bookingId);
        
        if (booking == null) {
            System.err.println("Booking not found");
            return false;
        }
        
        // Addons can be added to CONFIRMED, CHECKED_IN bookings
        if (booking.getBookingStatus() != Booking.BookingStatus.CONFIRMED && 
            booking.getBookingStatus() != Booking.BookingStatus.CHECKED_IN) {
            System.err.println("Addons can only be added to confirmed or checked-in bookings");
            return false;
        }
        
        return true;
    }
}
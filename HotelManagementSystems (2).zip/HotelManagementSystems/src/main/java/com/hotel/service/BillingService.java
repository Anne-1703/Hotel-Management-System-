package com.hotel.service;

import com.hotel.dao.AddonDAO;
import com.hotel.dao.BillDAO;
import com.hotel.dao.BookingDAO;
import com.hotel.models.Bill;
import com.hotel.models.Bill.PaymentStatus;
import com.hotel.models.Booking;
import java.util.List;

/**
 * BillingService - Handles billing operations and calculations
 */
public class BillingService {
    
    private final BillDAO billDAO;
    private final BookingDAO bookingDAO;
    private final AddonDAO addonDAO;
    private final BookingService bookingService;
    
    public BillingService() {
        this.billDAO = new BillDAO();
        this.bookingDAO = new BookingDAO();
        this.addonDAO = new AddonDAO();
        this.bookingService = new BookingService();
    }
    
    /**
     * Generate bill for a booking
     * @param bookingId Booking ID
     * @return Bill object if successful, null otherwise
     */
    public Bill generateBill(int bookingId) {
        // Check if bill already exists
        if (billDAO.billExistsForBooking(bookingId)) {
            System.out.println("Bill already exists for this booking");
            return billDAO.getBillByBookingId(bookingId);
        }
        
        // Get booking details
        Booking booking = bookingDAO.getBookingById(bookingId);
        if (booking == null) {
            System.err.println("Booking not found");
            return null;
        }
        
        // Calculate room charges
        double roomCharges = bookingService.calculateRoomCharges(
            booking.getRoomId(), 
            booking.getCheckInDate(), 
            booking.getCheckOutDate()
        );
        
        // Calculate addon charges
        double addonCharges = addonDAO.getTotalAddonCharges(bookingId);
        
        // Create bill
        Bill bill = new Bill(bookingId, roomCharges, addonCharges);
        bill.setPaymentStatus(PaymentStatus.UNPAID);
        
        boolean success = billDAO.createBill(bill);
        
        if (success) {
            System.out.println("✅ Bill generated successfully - ID: " + bill.getBillId());
            System.out.println("   Room Charges: ₹" + roomCharges);
            System.out.println("   Addon Charges: ₹" + addonCharges);
            System.out.println("   Tax (18%): ₹" + bill.getTaxAmount());
            System.out.println("   Total Amount: ₹" + bill.getTotalAmount());
            return bill;
        } else {
            System.err.println("❌ Failed to generate bill");
            return null;
        }
    }
    
    /**
     * Get bill by booking ID
     * @param bookingId Booking ID
     * @return Bill object
     */
    public Bill getBillByBookingId(int bookingId) {
        Bill bill = billDAO.getBillByBookingId(bookingId);
        
        if (bill == null) {
            System.out.println("No bill found for booking ID: " + bookingId);
        }
        
        return bill;
    }
    
    /**
     * Get bill by ID
     * @param billId Bill ID
     * @return Bill object
     */
    public Bill getBillById(int billId) {
        return billDAO.getBillById(billId);
    }
    
    /**
     * Process payment for a bill
     * @param billId Bill ID
     * @param paymentMethod Payment method (Cash, Card, UPI, etc.)
     * @return true if successful, false otherwise
     */
    public boolean processPayment(int billId, String paymentMethod) {
        Bill bill = billDAO.getBillById(billId);
        
        if (bill == null) {
            System.err.println("Bill not found");
            return false;
        }
        
        if (bill.isPaid()) {
            System.out.println("Bill is already paid");
            return true;
        }
        
        if (paymentMethod == null || paymentMethod.trim().isEmpty()) {
            System.err.println("Payment method is required");
            return false;
        }
        
        boolean success = billDAO.updatePaymentStatus(billId, PaymentStatus.PAID, paymentMethod);
        
        if (success) {
            System.out.println("✅ Payment processed successfully");
            System.out.println("   Bill ID: " + billId);
            System.out.println("   Amount: ₹" + bill.getTotalAmount());
            System.out.println("   Method: " + paymentMethod);
        } else {
            System.err.println("❌ Payment processing failed");
        }
        
        return success;
    }
    
    /**
     * Apply discount to a bill
     * @param billId Bill ID
     * @param discountAmount Discount amount
     * @return true if successful, false otherwise
     */
    public boolean applyDiscount(int billId, double discountAmount) {
        Bill bill = billDAO.getBillById(billId);
        
        if (bill == null) {
            System.err.println("Bill not found");
            return false;
        }
        
        if (discountAmount < 0) {
            System.err.println("Discount amount cannot be negative");
            return false;
        }
        
        double subtotal = bill.getRoomCharges() + bill.getAddonCharges();
        if (discountAmount > subtotal) {
            System.err.println("Discount cannot exceed subtotal");
            return false;
        }
        
        bill.setDiscountAmount(discountAmount);
        bill.calculateTotal();
        
        boolean success = billDAO.updateBill(bill);
        
        if (success) {
            System.out.println("✅ Discount applied successfully");
            System.out.println("   Discount: ₹" + discountAmount);
            System.out.println("   New Total: ₹" + bill.getTotalAmount());
        } else {
            System.err.println("❌ Failed to apply discount");
        }
        
        return success;
    }
    
    /**
     * Get all bills
     * @return List of bills
     */
    public List<Bill> getAllBills() {
        return billDAO.getAllBills();
    }
    
    /**
     * Get unpaid bills
     * @return List of unpaid bills
     */
    public List<Bill> getUnpaidBills() {
        return billDAO.getBillsByStatus(PaymentStatus.UNPAID);
    }
    
    /**
     * Get paid bills
     * @return List of paid bills
     */
    public List<Bill> getPaidBills() {
        return billDAO.getBillsByStatus(PaymentStatus.PAID);
    }
    
    /**
     * Get total revenue
     * @return Total revenue from paid bills
     */
    public double getTotalRevenue() {
        return billDAO.getTotalRevenue();
    }
    
    /**
     * Get pending payments total
     * @return Total amount of unpaid bills
     */
    public double getPendingPaymentsTotal() {
        return billDAO.getPendingPaymentsTotal();
    }
    
    /**
     * Calculate bill breakdown
     * @param bill Bill object
     * @return String with formatted breakdown
     */
    public String getBillBreakdown(Bill bill) {
        if (bill == null) {
            return "No bill data";
        }
        
        StringBuilder breakdown = new StringBuilder();
        breakdown.append("============== BILL BREAKDOWN ==============\n");
        breakdown.append(String.format("Bill ID: %d\n", bill.getBillId()));
        breakdown.append(String.format("Booking ID: %d\n", bill.getBookingId()));
        breakdown.append(String.format("Customer: %s\n", bill.getCustomerName()));
        breakdown.append(String.format("Room: %s\n", bill.getRoomNumber()));
        breakdown.append("-------------------------------------------\n");
        breakdown.append(String.format("Room Charges:      ₹%,.2f\n", bill.getRoomCharges()));
        breakdown.append(String.format("Addon Charges:     ₹%,.2f\n", bill.getAddonCharges()));
        breakdown.append(String.format("Subtotal:          ₹%,.2f\n", bill.getSubtotal()));
        breakdown.append(String.format("Discount:         -₹%,.2f\n", bill.getDiscountAmount()));
        breakdown.append(String.format("Tax (18%% GST):    ₹%,.2f\n", bill.getTaxAmount()));
        breakdown.append("-------------------------------------------\n");
        breakdown.append(String.format("TOTAL AMOUNT:      ₹%,.2f\n", bill.getTotalAmount()));
        breakdown.append("-------------------------------------------\n");
        breakdown.append(String.format("Payment Status: %s\n", bill.getPaymentStatus()));
        if (bill.getPaymentMethod() != null) {
            breakdown.append(String.format("Payment Method: %s\n", bill.getPaymentMethod()));
        }
        breakdown.append("===========================================\n");
        
        return breakdown.toString();
    }
    
    /**
     * Validate bill can be generated for booking
     * @param bookingId Booking ID
     * @return true if bill can be generated, false otherwise
     */
    public boolean canGenerateBill(int bookingId) {
        // Check if booking exists
        Booking booking = bookingDAO.getBookingById(bookingId);
        if (booking == null) {
            System.err.println("Booking not found");
            return false;
        }
        
        // Check if bill already exists
        if (billDAO.billExistsForBooking(bookingId)) {
            System.out.println("Bill already exists for this booking");
            return false;
        }
        
        // Bill can be generated for CHECKED_IN or CHECKED_OUT bookings
        if (booking.getBookingStatus() != Booking.BookingStatus.CHECKED_IN && 
            booking.getBookingStatus() != Booking.BookingStatus.CHECKED_OUT) {
            System.err.println("Bill can only be generated for checked-in or checked-out bookings");
            return false;
        }
        
        return true;
    }
}
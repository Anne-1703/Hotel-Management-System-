package com.hotel.service;

import com.hotel.dao.BillDAO;
import com.hotel.dao.BookingDAO;
import com.hotel.dao.CustomerDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.models.Bill;
import com.hotel.models.Booking;
import com.hotel.models.Customer;
import com.hotel.models.Room;
import java.sql.Date;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ReportService - Generates reports for occupancy and financial summaries
 */
public class ReportService {
    
    private final RoomDAO roomDAO;
    private final BookingDAO bookingDAO;
    private final BillDAO billDAO;
    private final CustomerDAO customerDAO;
    
    public ReportService() {
        this.roomDAO = new RoomDAO();
        this.bookingDAO = new BookingDAO();
        this.billDAO = new BillDAO();
        this.customerDAO = new CustomerDAO();
    }
    
    /**
     * Get total revenue from billing
     * @return Total revenue
     */
    public double getTotalRevenue() {
        return billDAO.getTotalRevenue();
    }
    
    /**
     * Generate occupancy report
     * @return Formatted occupancy report
     */
    public String generateOccupancyReport() {
        int[] stats = roomDAO.getOccupancyStats();
        int totalRooms = stats[0];
        int occupiedRooms = stats[1];
        int availableRooms = stats[2];
        
        double occupancyRate = totalRooms > 0 ? 
            (double) occupiedRooms / totalRooms * 100 : 0;
        
        StringBuilder report = new StringBuilder();
        report.append("╔═══════════════════════════════════════════╗\n");
        report.append("║       HOTEL OCCUPANCY REPORT          ║\n");
        report.append("╠═══════════════════════════════════════════╣\n");
        report.append(String.format("║ Total Rooms:          %3d            ║\n", totalRooms));
        report.append(String.format("║ Occupied Rooms:       %3d            ║\n", occupiedRooms));
        report.append(String.format("║ Available Rooms:      %3d            ║\n", availableRooms));
        report.append(String.format("║ Occupancy Rate:    %.1f%%              ║\n", occupancyRate));
        report.append("╠═══════════════════════════════════════════╣\n");
        
        // Today's check-ins and check-outs
        List<Booking> checkIns = bookingDAO.getTodayCheckIns();
        List<Booking> checkOuts = bookingDAO.getTodayCheckOuts();
        
        report.append(String.format("║ Today's Check-ins:    %3d             ║\n", checkIns.size()));
        report.append(String.format("║ Today's Check-outs:   %3d             ║\n", checkOuts.size()));
        report.append("╚═══════════════════════════════════════════╝\n");
        
        return report.toString();
    }
    
    /**
     * Generate financial summary report
     * @return Formatted financial report
     */
    public String generateFinancialReport() {
        double totalRevenue = billDAO.getTotalRevenue();
        double pendingPayments = billDAO.getPendingPaymentsTotal();
        
        List<Bill> paidBills = billDAO.getBillsByStatus(Bill.PaymentStatus.PAID);
        List<Bill> unpaidBills = billDAO.getBillsByStatus(Bill.PaymentStatus.UNPAID);
        
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════╗\n");
        report.append("║       FINANCIAL SUMMARY REPORT        ║\n");
        report.append("╠════════════════════════════════════════════╣\n");
        report.append(String.format("║ Total Revenue: ₹%,12.2f          ║\n", totalRevenue));
        report.append(String.format("║ Pending Payments:₹%,12.2f        ║\n", pendingPayments));
        report.append("╠════════════════════════════════════════════╣\n");
        report.append(String.format("║ Paid Bills:         %5d            ║\n", paidBills.size()));
        report.append(String.format("║ Unpaid Bills:       %5d            ║\n", unpaidBills.size()));
        report.append("╚════════════════════════════════════════════╝\n");
        
        return report.toString();
    }
    
    /**
     * Generate booking statistics report
     * @return Formatted booking statistics
     */
    public String generateBookingStatistics() {
        List<Booking> allBookings = bookingDAO.getAllBookings();
        
        // Count bookings by status
        Map<Booking.BookingStatus, Integer> statusCounts = new HashMap<>();
        for (Booking booking : allBookings) {
            statusCounts.put(booking.getBookingStatus(), 
                statusCounts.getOrDefault(booking.getBookingStatus(), 0) + 1);
        }
        
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════╗\n");
        report.append("║       BOOKING STATISTICS              ║\n");
        report.append("╠════════════════════════════════════════════╣\n");
        report.append(String.format("║ Total Bookings:     %5d            ║\n", allBookings.size()));
        report.append("╠════════════════════════════════════════════╣\n");
        
        for (Booking.BookingStatus status : Booking.BookingStatus.values()) {
            int count = statusCounts.getOrDefault(status, 0);
            report.append(String.format("║ %-20s %5d           ║\n", status.name() + ":", count));
        }
        
        report.append("╚════════════════════════════════════════════╝\n");
        
        return report.toString();
    }
    
    /**
     * Generate room type report
     * @return Formatted room type statistics
     */
    public String generateRoomTypeReport() {
        List<Room> allRooms = roomDAO.getAllRooms();
        
        Map<Room.RoomType, Integer> typeCounts = new HashMap<>();
        Map<Room.RoomType, Integer> availableCounts = new HashMap<>();
        
        for (Room room : allRooms) {
            typeCounts.put(room.getRoomType(), 
                typeCounts.getOrDefault(room.getRoomType(), 0) + 1);
            
            if (room.getStatus() == Room.RoomStatus.AVAILABLE) {
                availableCounts.put(room.getRoomType(), 
                    availableCounts.getOrDefault(room.getRoomType(), 0) + 1);
            }
        }
        
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════╗\n");
        report.append("║       ROOM TYPE REPORT                ║\n");
        report.append("╠════════════════════════════════════════════╣\n");
        report.append("║ Type      Total   Available   Occupied║\n");
        report.append("╠════════════════════════════════════════════╣\n");
        
        for (Room.RoomType type : Room.RoomType.values()) {
            int total = typeCounts.getOrDefault(type, 0);
            int available = availableCounts.getOrDefault(type, 0);
            int occupied = total - available;
            
            report.append(String.format("║ %-10s  %3d      %3d         %3d  ║\n", 
                type.name(), total, available, occupied));
        }
        
        report.append("╚════════════════════════════════════════════╝\n");
        
        return report.toString();
    }
    
    /**
     * Generate customer statistics report
     * @return Formatted customer statistics
     */
    public String generateCustomerReport() {
        List<Customer> allCustomers = customerDAO.getAllCustomers();
        
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════╗\n");
        report.append("║       CUSTOMER STATISTICS            ║\n");
        report.append("╠════════════════════════════════════════════╣\n");
        report.append(String.format("║ Total Customers:    %5d             ║\n", allCustomers.size()));
        report.append("╚════════════════════════════════════════════╝\n");
        
        return report.toString();
    }
    
    /**
     * Generate revenue by date range
     * @param startDate Start date
     * @param endDate End date
     * @return Formatted revenue report
     */
    public String generateRevenueReport(Date startDate, Date endDate) {
        double revenue = billDAO.getRevenueByDateRange(startDate, endDate);
        
        StringBuilder report = new StringBuilder();
        report.append("╔════════════════════════════════════════════╗\n");
        report.append("║       REVENUE REPORT                       ║\n");
        report.append("╠════════════════════════════════════════════╣\n");
        report.append(String.format("║ Period: %s to %s                     ║\n", startDate, endDate));
        report.append("╠════════════════════════════════════════════╣\n");
        report.append(String.format("║ Total Revenue:   ₹%,12.2f            ║\n", revenue));
        report.append("╚════════════════════════════════════════════╝\n");
        
        return report.toString();
    }
    
    /**
     * Generate today's summary
     * @return Complete daily summary
     */
    public String generateDailySummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("\n");
        summary.append("═══════════════════════════════════════════════\n");
        summary.append("          DAILY SUMMARY REPORT - " + LocalDate.now() + "\n");
        summary.append("═══════════════════════════════════════════════\n\n");
        
        // Occupancy
        summary.append(generateOccupancyReport());
        summary.append("\n");
        
        // Bookings
        List<Booking> checkIns = bookingDAO.getTodayCheckIns();
        List<Booking> checkOuts = bookingDAO.getTodayCheckOuts();
        
        if (!checkIns.isEmpty()) {
            summary.append("Today's Check-ins:\n");
            for (Booking b : checkIns) {
                summary.append(String.format("  - %s (Room %s)\n", 
                    b.getCustomerName(), b.getRoomNumber()));
            }
            summary.append("\n");
        }
        
        if (!checkOuts.isEmpty()) {
            summary.append("Today's Check-outs:\n");
            for (Booking b : checkOuts) {
                summary.append(String.format("  - %s (Room %s)\n", 
                    b.getCustomerName(), b.getRoomNumber()));
            }
            summary.append("\n");
        }
        
        // Financial summary
        summary.append(generateFinancialReport());
        
        return summary.toString();
    }
    
    /**
     * Generate complete management report
     * @return Comprehensive report
     */
    public String generateCompleteReport() {
        StringBuilder report = new StringBuilder();
        report.append("\n");
        report.append("═══════════════════════════════════════════════\n");
        report.append("        HOTEL MANAGEMENT REPORT\n");
        report.append("        Generated: " + LocalDate.now() + "\n");
        report.append("═══════════════════════════════════════════════\n\n");
        
        report.append(generateOccupancyReport());
        report.append("\n");
        report.append(generateRoomTypeReport());
        report.append("\n");
        report.append(generateBookingStatistics());
        report.append("\n");
        report.append(generateFinancialReport());
        report.append("\n");
        report.append(generateCustomerReport());
        
        return report.toString();
    }
    
    /**
     * Get occupancy rate
     * @return Occupancy rate percentage
     */
    public double getOccupancyRate() {
        int[] stats = roomDAO.getOccupancyStats();
        int totalRooms = stats[0];
        int occupiedRooms = stats[1];
        
        return totalRooms > 0 ? (double) occupiedRooms / totalRooms * 100 : 0;
    }
}
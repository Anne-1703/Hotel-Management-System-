package com.hotel.service;

import com.hotel.dao.BookingDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.models.Booking;
import com.hotel.models.Booking.BookingStatus;
import com.hotel.models.Room;
import com.hotel.models.Room.RoomStatus;
import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * BookingService - Handles booking operations and business logic
 */
public class BookingService {
    
    private final BookingDAO bookingDAO;
    private final RoomDAO roomDAO;
    
    public BookingService() {
        this.bookingDAO = new BookingDAO();
        this.roomDAO = new RoomDAO();
    }
    
    /**
     * Create new booking with validation
     * @param customerId Customer ID
     * @param roomId Room ID
     * @param checkInDate Check-in date
     * @param checkOutDate Check-out date
     * @return Booking object if successful, null otherwise
     */
    public Booking createBooking(int customerId, int roomId, Date checkInDate, Date checkOutDate) {
        // Validate dates
        if (checkInDate == null || checkOutDate == null) {
            System.err.println("Check-in and check-out dates are required");
            return null;
        }
        
        LocalDate checkIn = checkInDate.toLocalDate();
        LocalDate checkOut = checkOutDate.toLocalDate();
        LocalDate today = LocalDate.now();
        
        // Check if check-in is in the past
        if (checkIn.isBefore(today)) {
            System.err.println("Check-in date cannot be in the past");
            return null;
        }
        
        // Check if check-out is after check-in
        if (!checkOut.isAfter(checkIn)) {
            System.err.println("Check-out date must be after check-in date");
            return null;
        }
        
        // Calculate total nights
        long totalNights = ChronoUnit.DAYS.between(checkIn, checkOut);
        
        if (totalNights <= 0) {
            System.err.println("Invalid date range");
            return null;
        }
        
        // Check room availability
        if (!bookingDAO.isRoomAvailable(roomId, checkInDate, checkOutDate)) {
            System.err.println("Room is not available for selected dates");
            return null;
        }
        
        // Check if room exists and is available
        Room room = roomDAO.getRoomById(roomId);
        if (room == null) {
            System.err.println("Room not found");
            return null;
        }
        
        if (room.getStatus() != RoomStatus.AVAILABLE) {
            System.err.println("Room is not available");
            return null;
        }
        
        // Create booking
        Booking booking = new Booking(customerId, roomId, checkInDate, checkOutDate, (int) totalNights);
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        
        boolean success = bookingDAO.createBooking(booking);
        
        if (success) {
            System.out.println("✅ Booking created successfully - ID: " + booking.getBookingId());
            return booking;
        } else {
            System.err.println("❌ Failed to create booking");
            return null;
        }
    }
    
    /**
     * Calculate room charges with seasonal pricing
     * @param roomId Room ID
     * @param checkInDate Check-in date
     * @param checkOutDate Check-out date
     * @return Total room charges
     */
    public double calculateRoomCharges(int roomId, Date checkInDate, Date checkOutDate) {
        Room room = roomDAO.getRoomById(roomId);
        if (room == null) {
            return 0.0;
        }
        
        LocalDate checkIn = checkInDate.toLocalDate();
        LocalDate checkOut = checkOutDate.toLocalDate();
        long totalNights = ChronoUnit.DAYS.between(checkIn, checkOut);
        
        double basePrice = room.getBasePrice();
        double multiplier = getSeasonalMultiplier(checkInDate);
        
        double totalCharges = basePrice * totalNights * multiplier;
        
        System.out.println("Room Charges Calculation:");
        System.out.println("  Base Price: ₹" + basePrice);
        System.out.println("  Total Nights: " + totalNights);
        System.out.println("  Seasonal Multiplier: " + multiplier);
        System.out.println("  Total: ₹" + totalCharges);
        
        return totalCharges;
    }
    
    /**
     * Get seasonal pricing multiplier for a date
     * @param date Date to check
     * @return Multiplier (1.0 = normal, >1.0 = peak season)
     */
    private double getSeasonalMultiplier(Date date) {
        // This is a simplified version
        // In production, this should query the seasonal_pricing table
        LocalDate localDate = date.toLocalDate();
        int month = localDate.getMonthValue();
        
        // Peak season: December-January (1.5x)
        if (month == 12 || month == 1) {
            return 1.5;
        }
        
        // Festival season: October-November (1.4x)
        if (month == 10 || month == 11) {
            return 1.4;
        }
        
        // Summer season: April-June (1.3x)
        if (month >= 4 && month <= 6) {
            return 1.3;
        }
        
        // Normal season
        return 1.0;
    }
    
    /**
     * Check-in a booking
     * @param bookingId Booking ID
     * @return true if successful, false otherwise
     */
    public boolean checkIn(int bookingId) {
        Booking booking = bookingDAO.getBookingById(bookingId);
        
        if (booking == null) {
            System.err.println("Booking not found");
            return false;
        }
        
        if (!booking.canCheckIn()) {
            System.err.println("Booking cannot be checked in - Status: " + booking.getBookingStatus());
            return false;
        }
        
        // Update booking status
        boolean bookingUpdated = bookingDAO.updateBookingStatus(bookingId, BookingStatus.CHECKED_IN);
        
        // Update room status
        boolean roomUpdated = roomDAO.updateRoomStatus(booking.getRoomId(), RoomStatus.OCCUPIED);
        
        if (bookingUpdated && roomUpdated) {
            System.out.println("✅ Check-in successful for Booking ID: " + bookingId);
            return true;
        } else {
            System.err.println("❌ Check-in failed");
            return false;
        }
    }
    
    /**
     * Check-out a booking
     * @param bookingId Booking ID
     * @return true if successful, false otherwise
     */
    public boolean checkOut(int bookingId) {
        Booking booking = bookingDAO.getBookingById(bookingId);
        
        if (booking == null) {
            System.err.println("Booking not found");
            return false;
        }
        
        if (!booking.canCheckOut()) {
            System.err.println("Booking cannot be checked out - Status: " + booking.getBookingStatus());
            return false;
        }
        
        // Update booking status
        boolean bookingUpdated = bookingDAO.updateBookingStatus(bookingId, BookingStatus.CHECKED_OUT);
        
        // Update room status
        boolean roomUpdated = roomDAO.updateRoomStatus(booking.getRoomId(), RoomStatus.AVAILABLE);
        
        if (bookingUpdated && roomUpdated) {
            System.out.println("✅ Check-out successful for Booking ID: " + bookingId);
            return true;
        } else {
            System.err.println("❌ Check-out failed");
            return false;
        }
    }
    
    /**
     * Cancel a booking
     * @param bookingId Booking ID
     * @return true if successful, false otherwise
     */
    public boolean cancelBooking(int bookingId) {
        Booking booking = bookingDAO.getBookingById(bookingId);
        
        if (booking == null) {
            System.err.println("Booking not found");
            return false;
        }
        
        // Can only cancel PENDING or CONFIRMED bookings
        if (booking.getBookingStatus() != BookingStatus.PENDING && 
            booking.getBookingStatus() != BookingStatus.CONFIRMED) {
            System.err.println("Booking cannot be cancelled - Status: " + booking.getBookingStatus());
            return false;
        }
        
        boolean success = bookingDAO.cancelBooking(bookingId);
        
        if (success) {
            System.out.println("✅ Booking cancelled successfully");
        } else {
            System.err.println("❌ Failed to cancel booking");
        }
        
        return success;
    }
    
    /**
     * Get customer bookings
     * @param customerId Customer ID
     * @return List of bookings
     */
    public List<Booking> getCustomerBookings(int customerId) {
        return bookingDAO.getBookingsByCustomerId(customerId);
    }
    
    /**
     * Get all bookings
     * @return List of all bookings
     */
    public List<Booking> getAllBookings() {
        return bookingDAO.getAllBookings();
    }
    
    /**
     * Get booking by ID
     * @param bookingId Booking ID
     * @return Booking object
     */
    public Booking getBookingById(int bookingId) {
        return bookingDAO.getBookingById(bookingId);
    }
    
    /**
     * Get today's check-ins
     * @return List of bookings
     */
    public List<Booking> getTodayCheckIns() {
        return bookingDAO.getTodayCheckIns();
    }
    
    /**
     * Get today's check-outs
     * @return List of bookings
     */
    public List<Booking> getTodayCheckOuts() {
        return bookingDAO.getTodayCheckOuts();
    }
    
    /**
     * Get active bookings (CONFIRMED or CHECKED_IN)
     * @return List of active bookings
     */
    public List<Booking> getActiveBookings() {
        List<Booking> confirmed = bookingDAO.getBookingsByStatus(BookingStatus.CONFIRMED);
        List<Booking> checkedIn = bookingDAO.getBookingsByStatus(BookingStatus.CHECKED_IN);
        confirmed.addAll(checkedIn);
        return confirmed;
    }
}
package com.hotel.ui;

import com.hotel.dao.BillDAO;
import com.hotel.models.Bill;
import com.hotel.models.Booking;
import com.hotel.models.Customer;
import com.hotel.service.BookingService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * My Bookings Page - View customer's booking history
 */
public class MyBookingsPage extends JPanel {
    
    private Customer customer;
    private BookingService bookingService;
    private BillDAO billDAO;
    
    private JTable bookingTable;
    private DefaultTableModel tableModel;
    private JTextArea detailsArea;
    
    public MyBookingsPage(Customer customer) {
        this.customer = customer;
        this.bookingService = new BookingService();
        this.billDAO = new BillDAO();
        initComponents();
        loadBookings();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("My Bookings");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.addActionListener(e -> loadBookings());
        headerPanel.add(refreshBtn, BorderLayout.EAST);
        
        // Bookings table
        String[] columns = {"Booking ID", "Room", "Check-in", "Check-out", "Nights", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        bookingTable = new JTable(tableModel);
        bookingTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        bookingTable.setRowHeight(30);
        bookingTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                showBookingDetails();
            }
        });
        
        JScrollPane tableScroll = new JScrollPane(bookingTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Booking History"));
        
        // Details panel
        JPanel detailsPanel = new JPanel(new BorderLayout());
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Booking Details"));
        
        detailsArea = new JTextArea();
        detailsArea.setEditable(false);
        detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        detailsArea.setMargin(new Insets(10, 10, 10, 10));
        
        JScrollPane detailsScroll = new JScrollPane(detailsArea);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        JButton cancelBtn = new JButton("Cancel Booking");
        cancelBtn.setBackground(new Color(231, 76, 60));
        cancelBtn.setForeground(Color.BLUE);
        cancelBtn.setFocusPainted(false);
        cancelBtn.addActionListener(e -> cancelBooking());
        
        JButton viewBillBtn = new JButton("View Bill");
        viewBillBtn.setBackground(new Color(52, 152, 219));
        viewBillBtn.setForeground(Color.BLUE);
        viewBillBtn.setFocusPainted(false);
        viewBillBtn.addActionListener(e -> viewBill());
        
        buttonPanel.add(cancelBtn);
        buttonPanel.add(viewBillBtn);
        
        detailsPanel.add(detailsScroll, BorderLayout.CENTER);
        detailsPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tableScroll, detailsPanel);
        splitPane.setDividerLocation(550);
        splitPane.setResizeWeight(0.6);
        
        add(headerPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);
    }
    
    private void loadBookings() {
        tableModel.setRowCount(0);
        List<Booking> bookings = bookingService.getCustomerBookings(customer.getCustomerId());
        
        for (Booking booking : bookings) {
            tableModel.addRow(new Object[]{
                booking.getBookingId(),
                booking.getRoomNumber() + " (" + booking.getRoomType() + ")",
                booking.getCheckInDate(),
                booking.getCheckOutDate(),
                booking.getTotalNights(),
                booking.getBookingStatus()
            });
        }
        
        if (bookings.isEmpty()) {
            detailsArea.setText("No bookings found.\nBook a room from the 'Book Room' tab!");
        }
    }
    
    private void showBookingDetails() {
        int selectedRow = bookingTable.getSelectedRow();
        if (selectedRow < 0) {
            detailsArea.setText("");
            return;
        }
        
        int bookingId = (Integer) tableModel.getValueAt(selectedRow, 0);
        Booking booking = bookingService.getBookingById(bookingId);
        
        if (booking == null) {
            detailsArea.setText("Unable to load booking details.");
            return;
        }
        
        StringBuilder details = new StringBuilder();
        details.append("═══════════════════════════════════════\n");
        details.append("           BOOKING DETAILS\n");
        details.append("═══════════════════════════════════════\n\n");
        details.append(String.format("Booking ID:      %d\n", booking.getBookingId()));
        details.append(String.format("Customer:        %s\n", booking.getCustomerName()));
        details.append(String.format("Room Number:     %s\n", booking.getRoomNumber()));
        details.append(String.format("Room Type:       %s\n", booking.getRoomType()));
        details.append(String.format("Check-in Date:   %s\n", booking.getCheckInDate()));
        details.append(String.format("Check-out Date:  %s\n", booking.getCheckOutDate()));
        details.append(String.format("Total Nights:    %d\n", booking.getTotalNights()));
        details.append(String.format("Status:          %s\n", booking.getBookingStatus()));
        details.append(String.format("Booked On:       %s\n", booking.getBookingDate()));
        
        // Check if bill exists
        Bill bill = billDAO.getBillByBookingId(bookingId);
        if (bill != null) {
            details.append("\n─────────────────────────────────────\n");
            details.append("              BILLING INFO\n");
            details.append("─────────────────────────────────────\n\n");
            details.append(String.format("Bill ID:         %d\n", bill.getBillId()));
            details.append(String.format("Room Charges:    ₹%.2f\n", bill.getRoomCharges()));
            details.append(String.format("Addon Charges:   ₹%.2f\n", bill.getAddonCharges()));
            details.append(String.format("Tax (18%% GST):  ₹%.2f\n", bill.getTaxAmount()));
            details.append(String.format("Discount:        ₹%.2f\n", bill.getDiscountAmount()));
            details.append(String.format("Total Amount:    ₹%.2f\n", bill.getTotalAmount()));
            details.append(String.format("Payment Status:  %s\n", bill.getPaymentStatus()));
            if (bill.getPaymentMethod() != null) {
                details.append(String.format("Payment Method:  %s\n", bill.getPaymentMethod()));
            }
        } else {
            details.append("\n─────────────────────────────────────\n");
            details.append("Bill not yet generated.\n");
        }
        
        details.append("\n═══════════════════════════════════════\n");
        
        detailsArea.setText(details.toString());
    }
    
    private void cancelBooking() {
        int selectedRow = bookingTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking to cancel!",
                "No Booking Selected",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookingId = (Integer) tableModel.getValueAt(selectedRow, 0);
        Booking booking = bookingService.getBookingById(bookingId);
        
        if (booking == null) {
            JOptionPane.showMessageDialog(this,
                "Unable to load booking details!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (booking.getBookingStatus() == Booking.BookingStatus.CANCELLED) {
            JOptionPane.showMessageDialog(this,
                "This booking is already cancelled!",
                "Already Cancelled",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        if (booking.getBookingStatus() == Booking.BookingStatus.CHECKED_IN ||
            booking.getBookingStatus() == Booking.BookingStatus.CHECKED_OUT) {
            JOptionPane.showMessageDialog(this,
                "Cannot cancel a booking that is checked-in or completed!",
                "Cannot Cancel",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            String.format("Are you sure you want to cancel booking #%d?\n\nRoom: %s\nCheck-in: %s",
                bookingId, booking.getRoomNumber(), booking.getCheckInDate()),
            "Confirm Cancellation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = bookingService.cancelBooking(bookingId);
            
            if (success) {
                JOptionPane.showMessageDialog(this,
                    "Booking cancelled successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                loadBookings();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to cancel booking!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void viewBill() {
        int selectedRow = bookingTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking to view bill!",
                "No Booking Selected",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookingId = (Integer) tableModel.getValueAt(selectedRow, 0);
        Bill bill = billDAO.getBillByBookingId(bookingId);
        
        if (bill == null) {
            JOptionPane.showMessageDialog(this,
                "Bill has not been generated for this booking yet.\n\n" +
                "Bills are generated during check-out.",
                "No Bill Available",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        // Show bill in dialog
        JDialog billDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Bill Details", true);
        billDialog.setSize(500, 600);
        billDialog.setLocationRelativeTo(this);
        
        JTextArea billArea = new JTextArea();
        billArea.setEditable(false);
        billArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        billArea.setMargin(new Insets(15, 15, 15, 15));
        
        StringBuilder billText = new StringBuilder();
        billText.append("╔════════════════════════════════════════════╗\n");
        billText.append("║         HOTEL MANAGEMENT SYSTEM            ║\n");
        billText.append("║              BILLING RECEIPT               ║\n");
        billText.append("╠════════════════════════════════════════════╣\n");
        billText.append(String.format("║ Bill ID:           %-23d ║\n", bill.getBillId()));
        billText.append(String.format("║ Booking ID:        %-23d ║\n", bill.getBookingId()));
        billText.append(String.format("║ Customer:          %-23s ║\n", bill.getCustomerName()));
        billText.append(String.format("║ Room:              %-23s ║\n", bill.getRoomNumber()));
        billText.append(String.format("║ Date:              %-23s ║\n", bill.getBillDate().toString().substring(0, 10)));
        billText.append("╠════════════════════════════════════════════╣\n");
        billText.append(String.format("║ Room Charges:      ₹%,18.2f║\n", bill.getRoomCharges()));
        billText.append(String.format("║ Addon Charges:     ₹%,18.2f║\n", bill.getAddonCharges()));
        billText.append(String.format("║ Subtotal:          ₹%,18.2f║\n", bill.getSubtotal()));
        billText.append(String.format("║ Discount:         -₹%,18.2f║\n", bill.getDiscountAmount()));
        billText.append(String.format("║ Tax (18%% GST):     ₹%,18.2f║\n", bill.getTaxAmount()));
        billText.append("╠════════════════════════════════════════════╣\n");
        billText.append(String.format("║ TOTAL AMOUNT:      ₹%,18.2f║\n", bill.getTotalAmount()));
        billText.append("╠════════════════════════════════════════════╣\n");
        billText.append(String.format("║ Payment Status:    %-23s ║\n", bill.getPaymentStatus()));
        if (bill.getPaymentMethod() != null) {
            billText.append(String.format("║ Payment Method:    %-23s ║\n", bill.getPaymentMethod()));
        }
        billText.append("╚════════════════════════════════════════════╝\n");
        billText.append("\n       Thank you for choosing our hotel!\n");
        
        billArea.setText(billText.toString());
        
        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> billDialog.dispose());
        
        JPanel btnPanel = new JPanel();
        btnPanel.add(closeBtn);
        
        billDialog.add(new JScrollPane(billArea), BorderLayout.CENTER);
        billDialog.add(btnPanel, BorderLayout.SOUTH);
        billDialog.setVisible(true);
    }
}
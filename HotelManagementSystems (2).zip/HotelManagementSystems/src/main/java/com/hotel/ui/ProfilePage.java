package com.hotel.ui;

import com.hotel.models.Customer;
import com.hotel.service.AuthService;
import javax.swing.*;
import java.awt.*;

/**
 * Profile Page - Customer can view and update their profile
 */
public class ProfilePage extends JPanel {
    
    private Customer customer;
    private AuthService authService;
    
    private JTextField fullNameField;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextArea addressArea;
    private JPasswordField oldPasswordField;
    private JPasswordField newPasswordField;
    private JPasswordField confirmPasswordField;
    
    public ProfilePage(Customer customer) {
        this.customer = customer;
        this.authService = new AuthService();
        initComponents();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JLabel titleLabel = new JLabel("👤 My Profile");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        // Main panel with tabs
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Profile info tab
        JPanel profilePanel = createProfilePanel();
        tabbedPane.addTab("Profile Information", profilePanel);
        
        // Change password tab
        JPanel passwordPanel = createPasswordPanel();
        tabbedPane.addTab("Change Password", passwordPanel);
        
        add(titleLabel, BorderLayout.NORTH);
        add(tabbedPane, BorderLayout.CENTER);
    }
    
    private JPanel createProfilePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Username (read-only)
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        JTextField usernameField = new JTextField(customer.getUsername());
        usernameField.setEditable(false);
        usernameField.setBackground(new Color(236, 240, 241));
        usernameField.setPreferredSize(new Dimension(300, 35));
        
        // Full Name
        JLabel fullNameLabel = new JLabel("Full Name:");
        fullNameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        fullNameField = new JTextField(customer.getFullName());
        fullNameField.setPreferredSize(new Dimension(300, 35));
        
        // Email
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 14));
        emailField = new JTextField(customer.getEmail());
        emailField.setPreferredSize(new Dimension(300, 35));
        
        // Phone
        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(new Font("Arial", Font.BOLD, 14));
        phoneField = new JTextField(customer.getPhone());
        phoneField.setPreferredSize(new Dimension(300, 35));
        
        // Address
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setFont(new Font("Arial", Font.BOLD, 14));
        addressArea = new JTextArea(customer.getAddress(), 3, 20);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        JScrollPane addressScroll = new JScrollPane(addressArea);
        addressScroll.setPreferredSize(new Dimension(300, 80));
        
        // Update button
        JButton updateBtn = new JButton("Update Profile");
        updateBtn.setBackground(new Color(46, 204, 113));
        updateBtn.setForeground(Color.BLACK);
        updateBtn.setFont(new Font("Arial", Font.BOLD, 14));
        updateBtn.setFocusPainted(false);
        updateBtn.setPreferredSize(new Dimension(200, 40));
        updateBtn.addActionListener(e -> updateProfile());
        
        // Add components
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        panel.add(usernameLabel, gbc);
        gbc.gridx = 1;
        panel.add(usernameField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(fullNameLabel, gbc);
        gbc.gridx = 1;
        panel.add(fullNameField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(emailLabel, gbc);
        gbc.gridx = 1;
        panel.add(emailField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(phoneLabel, gbc);
        gbc.gridx = 1;
        panel.add(phoneField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.anchor = GridBagConstraints.NORTHWEST;
        panel.add(addressLabel, gbc);
        gbc.gridx = 1;
        panel.add(addressScroll, gbc);
        
        gbc.gridx = 1; gbc.gridy = 5;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 10, 10, 10);
        panel.add(updateBtn, gbc);
        
        return panel;
    }
    
    private JPanel createPasswordPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Old password
        JLabel oldPasswordLabel = new JLabel("Current Password:");
        oldPasswordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        oldPasswordField = new JPasswordField();
        oldPasswordField.setPreferredSize(new Dimension(300, 35));
        
        // New password
        JLabel newPasswordLabel = new JLabel("New Password:");
        newPasswordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        newPasswordField = new JPasswordField();
        newPasswordField.setPreferredSize(new Dimension(300, 35));
        
        // Confirm password
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setPreferredSize(new Dimension(300, 35));
        
        // Info label
        JLabel infoLabel = new JLabel("<html><i>Password must be at least 6 characters</i></html>");
        infoLabel.setForeground(new Color(127, 140, 141));
        
        // Change password button
        JButton changeBtn = new JButton("Change Password");
        changeBtn.setBackground(new Color(52, 152, 219));
        changeBtn.setForeground(Color.BLACK);
        changeBtn.setFont(new Font("Arial", Font.BOLD, 14));
        changeBtn.setFocusPainted(false);
        changeBtn.setPreferredSize(new Dimension(200, 40));
        changeBtn.addActionListener(e -> changePassword());
        
        // Add components
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        panel.add(oldPasswordLabel, gbc);
        gbc.gridx = 1;
        panel.add(oldPasswordField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(newPasswordLabel, gbc);
        gbc.gridx = 1;
        panel.add(newPasswordField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(confirmPasswordLabel, gbc);
        gbc.gridx = 1;
        panel.add(confirmPasswordField, gbc);
        
        gbc.gridx = 1; gbc.gridy = 3;
        panel.add(infoLabel, gbc);
        
        gbc.gridx = 1; gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 10, 10, 10);
        panel.add(changeBtn, gbc);
        
        return panel;
    }
    
    private void updateProfile() {
        String fullName = fullNameField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressArea.getText().trim();
        
        // Validate
        if (fullName.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Full name cannot be empty!",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!authService.isValidEmail(email)) {
            JOptionPane.showMessageDialog(this,
                "Please enter a valid email address!",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!authService.isValidPhone(phone)) {
            JOptionPane.showMessageDialog(this,
                "Please enter a valid 10-digit phone number!",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Update customer object
        customer.setFullName(fullName);
        customer.setEmail(email);
        customer.setPhone(phone);
        customer.setAddress(address);
        
        boolean success = authService.updateCustomerProfile(customer);
        
        if (success) {
            JOptionPane.showMessageDialog(this,
                "Profile updated successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                "Failed to update profile!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void changePassword() {
        String oldPassword = new String(oldPasswordField.getPassword());
        String newPassword = new String(newPasswordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        // Validate
        if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "All password fields are required!",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (newPassword.length() < 6) {
            JOptionPane.showMessageDialog(this,
                "New password must be at least 6 characters!",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!newPassword.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this,
                "New passwords do not match!",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Note: In production, verify old password first
        // For this implementation, we'll skip that verification
        
        boolean success = authService.changeCustomerPassword(customer.getCustomerId(), oldPassword, newPassword);
        
        if (success) {
            JOptionPane.showMessageDialog(this,
                "Password changed successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Clear fields
            oldPasswordField.setText("");
            newPasswordField.setText("");
            confirmPasswordField.setText("");
        } else {
            JOptionPane.showMessageDialog(this,
                "Failed to change password!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}
package com.hotel.ui;

import com.hotel.dao.RoomDAO;
import com.hotel.models.Admin;
import com.hotel.models.Room;
import com.hotel.models.Room.RoomStatus;
import com.hotel.models.Room.RoomType;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Room Management Page for Admin
 */
public class RoomManagementPage extends JPanel {
    
    @SuppressWarnings("unused")
    private Admin admin;
    private RoomDAO roomDAO;
    
    private JTable roomTable;
    private DefaultTableModel tableModel;
    
    public RoomManagementPage(Admin admin) {
        this.admin = admin;
        this.roomDAO = new RoomDAO();
        initComponents();
        loadRooms();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Room Management");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(Color.WHITE);
        
        JButton addBtn = new JButton("Add Room");
        addBtn.setBackground(new Color(46, 204, 113));
        addBtn.setForeground(Color.RED);
        addBtn.setFont(new Font("Arial", Font.BOLD, 12));
        addBtn.setFocusPainted(false);
        addBtn.addActionListener(e -> showAddRoomDialog());
        
        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.setFont(new Font("Arial", Font.BOLD, 12));
        refreshBtn.addActionListener(e -> loadRooms());
        
        buttonPanel.add(addBtn);
        buttonPanel.add(refreshBtn);
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(buttonPanel, BorderLayout.EAST);
        
        // Table
        String[] columns = {"Room No", "Type", "Base Price", "Capacity", "Status", "Description"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        roomTable = new JTable(tableModel);
        roomTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        roomTable.setRowHeight(30);
        
        JScrollPane scrollPane = new JScrollPane(roomTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("All Rooms"));
        
        // Action buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        actionPanel.setBackground(Color.WHITE);
        
        JButton editBtn = new JButton("Edit Room");
        editBtn.setBackground(new Color(52, 152, 219));
        editBtn.setForeground(Color.RED);
        editBtn.setFont(new Font("Arial", Font.BOLD, 12));
        editBtn.setFocusPainted(false);
        editBtn.addActionListener(e -> showEditRoomDialog());
        
        JButton changeStatusBtn = new JButton("Change Status");
        changeStatusBtn.setBackground(new Color(243, 156, 18));
        changeStatusBtn.setForeground(Color.RED);
        changeStatusBtn.setFont(new Font("Arial", Font.BOLD, 12));
        changeStatusBtn.setFocusPainted(false);
        changeStatusBtn.addActionListener(e -> changeRoomStatus());
        
        JButton deleteBtn = new JButton("Delete Room");
        deleteBtn.setBackground(new Color(231, 76, 60));
        deleteBtn.setForeground(Color.RED);
        deleteBtn.setFont(new Font("Arial", Font.BOLD, 12));
        deleteBtn.setFocusPainted(false);
        deleteBtn.addActionListener(e -> deleteRoom());
        
        actionPanel.add(editBtn);
        actionPanel.add(changeStatusBtn);
        actionPanel.add(deleteBtn);
        
        add(headerPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(actionPanel, BorderLayout.SOUTH);
    }
    
    private void loadRooms() {
        tableModel.setRowCount(0);
        List<Room> rooms = roomDAO.getAllRooms();
        
        for (Room room : rooms) {
            tableModel.addRow(new Object[]{
                room.getRoomNumber(),
                room.getRoomType(),
                String.format("₹%.2f", room.getBasePrice()),
                room.getCapacity(),
                room.getStatus(),
                room.getDescription()
            });
        }
    }
    
    private void showAddRoomDialog() {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Add New Room", true);
        dialog.setSize(450, 400);
        dialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Fields
        JTextField roomNumberField = new JTextField(15);
        JComboBox<RoomType> roomTypeCombo = new JComboBox<>(RoomType.values());
        JTextField basePriceField = new JTextField(15);
        JSpinner capacitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        JComboBox<RoomStatus> statusCombo = new JComboBox<>(RoomStatus.values());
        JTextArea descriptionArea = new JTextArea(3, 15);
        descriptionArea.setLineWrap(true);
        JScrollPane descScroll = new JScrollPane(descriptionArea);
        
        // Add components
        addFormField(panel, gbc, 0, "Room Number:", roomNumberField);
        addFormField(panel, gbc, 1, "Room Type:", roomTypeCombo);
        addFormField(panel, gbc, 2, "Base Price (₹):", basePriceField);
        addFormField(panel, gbc, 3, "Capacity:", capacitySpinner);
        addFormField(panel, gbc, 4, "Status:", statusCombo);
        addFormField(panel, gbc, 5, "Description:", descScroll);
        
        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton saveBtn = new JButton("Save");
        JButton cancelBtn = new JButton("Cancel");
        
        saveBtn.addActionListener(e -> {
            try {
                String roomNumber = roomNumberField.getText().trim();
                double basePrice = Double.parseDouble(basePriceField.getText().trim());
                int capacity = (Integer) capacitySpinner.getValue();
                
                if (roomNumber.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Room number is required!");
                    return;
                }
                
                Room room = new Room();
                room.setRoomNumber(roomNumber);
                room.setRoomType((RoomType) roomTypeCombo.getSelectedItem());
                room.setBasePrice(basePrice);
                room.setCapacity(capacity);
                room.setStatus((RoomStatus) statusCombo.getSelectedItem());
                room.setDescription(descriptionArea.getText().trim());
                
                boolean success = roomDAO.createRoom(room);
                
                if (success) {
                    JOptionPane.showMessageDialog(dialog, "Room added successfully!");
                    dialog.dispose();
                    loadRooms();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Failed to add room!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid price format!");
            }
        });
        
        cancelBtn.addActionListener(e -> dialog.dispose());
        
        btnPanel.add(saveBtn);
        btnPanel.add(cancelBtn);
        
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        panel.add(btnPanel, gbc);
        
        dialog.add(new JScrollPane(panel));
        dialog.setVisible(true);
    }
    
    private void showEditRoomDialog() {
        int selectedRow = roomTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a room to edit!");
            return;
        }
        
        String roomNumber = (String) tableModel.getValueAt(selectedRow, 0);
        Room room = roomDAO.getRoomByNumber(roomNumber);
        
        if (room == null) {
            JOptionPane.showMessageDialog(this, "Room not found!");
            return;
        }
        
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Edit Room", true);
        dialog.setSize(450, 400);
        dialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Fields
        JTextField roomNumberField = new JTextField(room.getRoomNumber(), 15);
        JComboBox<RoomType> roomTypeCombo = new JComboBox<>(RoomType.values());
        roomTypeCombo.setSelectedItem(room.getRoomType());
        JTextField basePriceField = new JTextField(String.valueOf(room.getBasePrice()), 15);
        JSpinner capacitySpinner = new JSpinner(new SpinnerNumberModel(room.getCapacity(), 1, 10, 1));
        JComboBox<RoomStatus> statusCombo = new JComboBox<>(RoomStatus.values());
        statusCombo.setSelectedItem(room.getStatus());
        JTextArea descriptionArea = new JTextArea(room.getDescription(), 3, 15);
        descriptionArea.setLineWrap(true);
        JScrollPane descScroll = new JScrollPane(descriptionArea);
        
        // Add components
        addFormField(panel, gbc, 0, "Room Number:", roomNumberField);
        addFormField(panel, gbc, 1, "Room Type:", roomTypeCombo);
        addFormField(panel, gbc, 2, "Base Price (₹):", basePriceField);
        addFormField(panel, gbc, 3, "Capacity:", capacitySpinner);
        addFormField(panel, gbc, 4, "Status:", statusCombo);
        addFormField(panel, gbc, 5, "Description:", descScroll);
        
        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton saveBtn = new JButton("Update");
        JButton cancelBtn = new JButton("Cancel");
        
        saveBtn.addActionListener(e -> {
            try {
                room.setRoomNumber(roomNumberField.getText().trim());
                room.setRoomType((RoomType) roomTypeCombo.getSelectedItem());
                room.setBasePrice(Double.parseDouble(basePriceField.getText().trim()));
                room.setCapacity((Integer) capacitySpinner.getValue());
                room.setStatus((RoomStatus) statusCombo.getSelectedItem());
                room.setDescription(descriptionArea.getText().trim());
                
                boolean success = roomDAO.updateRoom(room);
                
                if (success) {
                    JOptionPane.showMessageDialog(dialog, "Room updated successfully!");
                    dialog.dispose();
                    loadRooms();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Failed to update room!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid price format!");
            }
        });
        
        cancelBtn.addActionListener(e -> dialog.dispose());
        
        btnPanel.add(saveBtn);
        btnPanel.add(cancelBtn);
        
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        panel.add(btnPanel, gbc);
        
        dialog.add(new JScrollPane(panel));
        dialog.setVisible(true);
    }
    
    private void changeRoomStatus() {
        int selectedRow = roomTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a room!");
            return;
        }
        
        String roomNumber = (String) tableModel.getValueAt(selectedRow, 0);
        Room room = roomDAO.getRoomByNumber(roomNumber);
        
        if (room == null) {
            JOptionPane.showMessageDialog(this, "Room not found!");
            return;
        }
        
        RoomStatus newStatus = (RoomStatus) JOptionPane.showInputDialog(
            this,
            "Select new status for Room " + roomNumber + ":",
            "Change Room Status",
            JOptionPane.QUESTION_MESSAGE,
            null,
            RoomStatus.values(),
            room.getStatus()
        );
        
        if (newStatus != null && newStatus != room.getStatus()) {
            boolean success = roomDAO.updateRoomStatus(room.getRoomId(), newStatus);
            
            if (success) {
                JOptionPane.showMessageDialog(this, "Room status updated!");
                loadRooms();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update status!");
            }
        }
    }
    
    private void deleteRoom() {
        int selectedRow = roomTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a room to delete!");
            return;
        }
        
        String roomNumber = (String) tableModel.getValueAt(selectedRow, 0);
        Room room = roomDAO.getRoomByNumber(roomNumber);
        
        if (room == null) {
            JOptionPane.showMessageDialog(this, "Room not found!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete Room " + roomNumber + "?",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = roomDAO.deleteRoom(room.getRoomId());
            
            if (success) {
                JOptionPane.showMessageDialog(this, "Room deleted successfully!");
                loadRooms();
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Failed to delete room! Room may have existing bookings.");
            }
        }
    }
    
    private void addFormField(JPanel panel, GridBagConstraints gbc, int row, 
                             String label, JComponent field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(new JLabel(label), gbc);
        
        gbc.gridx = 1;
        panel.add(field, gbc);
    }
}
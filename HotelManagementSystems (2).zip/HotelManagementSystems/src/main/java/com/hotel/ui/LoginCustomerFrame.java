package com.hotel.ui;

import com.hotel.models.Customer;
import com.hotel.service.AuthService;
import javax.swing.*;
import java.awt.*;

/**
 * Customer Login Frame
 */
public class LoginCustomerFrame extends JFrame {
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    private AuthService authService;
    
    public LoginCustomerFrame() {
        this.authService = new AuthService();
        initComponents();
    }
    
    private void initComponents() {
        setTitle("Customer Login - Hotel Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 550);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Main panel with gradient
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(0, 0, new Color(52, 152, 219), 
                                                     0, getHeight(), new Color(41, 128, 185));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new BorderLayout());
        
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(30, 20, 20, 20));
        
        JLabel headerLabel = new JLabel("Customer Login");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 28));
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(headerLabel);
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setOpaque(false);
        formPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Username
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        usernameLabel.setForeground(Color.WHITE);
        
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        usernameField.setPreferredSize(new Dimension(250, 35));
        
        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        passwordLabel.setForeground(Color.WHITE);
        
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setPreferredSize(new Dimension(250, 35));
        
        // Add components to form
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(usernameLabel, gbc);
        
        gbc.gridy = 1;
        formPanel.add(usernameField, gbc);
        
        gbc.gridy = 2;
        formPanel.add(passwordLabel, gbc);
        
        gbc.gridy = 3;
        formPanel.add(passwordField, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        JButton loginBtn = createStyledButton("Login", new Color(46, 204, 113));
        loginBtn.addActionListener(e -> handleLogin());
        
        JButton registerBtn = createStyledButton("Register", new Color(52, 152, 219));
        registerBtn.addActionListener(e -> showRegisterDialog());
        
        JButton backBtn = createStyledButton("Back", new Color(149, 165, 166));
        backBtn.addActionListener(e -> {
            dispose();
            com.hotel.Main.main(new String[]{}); // FIXED: Static call
        });
        
        buttonPanel.add(loginBtn);
        buttonPanel.add(registerBtn);
        buttonPanel.add(backBtn);
        
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 20, 10, 20);
        formPanel.add(buttonPanel, gbc);
        
        // Add panels to main
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        add(mainPanel);
        
        // Enter key listener
        passwordField.addActionListener(e -> handleLogin());
    }
    
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please enter username and password",
                "Input Required",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Show loading cursor
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        
        Customer customer = authService.loginCustomer(username, password);
        
        setCursor(Cursor.getDefaultCursor());
        
        if (customer != null) {
            JOptionPane.showMessageDialog(this,
                "Welcome, " + customer.getFullName() + "!",
                "Login Successful",
                JOptionPane.INFORMATION_MESSAGE);
            
            // Open customer dashboard
            dispose();
            new CustomerDashboard(customer).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this,
                "Invalid username or password!",
                "Login Failed",
                JOptionPane.ERROR_MESSAGE);
            passwordField.setText("");
        }
    }
    
    private void showRegisterDialog() {
        JDialog registerDialog = new JDialog(this, "Customer Registration", true);
        registerDialog.setSize(400, 550);
        registerDialog.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Fields
        JTextField regUsername = new JTextField(20);
        JPasswordField regPassword = new JPasswordField(20);
        JPasswordField regConfirmPassword = new JPasswordField(20);
        JTextField regFullName = new JTextField(20);
        JTextField regEmail = new JTextField(20);
        JTextField regPhone = new JTextField(20);
        JTextArea regAddress = new JTextArea(3, 20);
        regAddress.setLineWrap(true);
        JScrollPane addressScroll = new JScrollPane(regAddress);
        
        // Add components
        int row = 0;
        addFormField(panel, gbc, row++, "Username:", regUsername);
        addFormField(panel, gbc, row++, "Password:", regPassword);
        addFormField(panel, gbc, row++, "Confirm Password:", regConfirmPassword);
        addFormField(panel, gbc, row++, "Full Name:", regFullName);
        addFormField(panel, gbc, row++, "Email:", regEmail);
        addFormField(panel, gbc, row++, "Phone:", regPhone);
        addFormField(panel, gbc, row++, "Address:", addressScroll);
        
        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton submitBtn = new JButton("Register");
        JButton cancelBtn = new JButton("Cancel");
        
        submitBtn.addActionListener(e -> {
            // Validate
            String username = regUsername.getText().trim();
            String password = new String(regPassword.getPassword());
            String confirmPassword = new String(regConfirmPassword.getPassword());
            String fullName = regFullName.getText().trim();
            String email = regEmail.getText().trim();
            String phone = regPhone.getText().trim();
            String address = regAddress.getText().trim();
            
            if (username.isEmpty() || password.isEmpty() || fullName.isEmpty() || 
                email.isEmpty() || phone.isEmpty()) {
                JOptionPane.showMessageDialog(registerDialog,
                    "All fields except address are required!",
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(registerDialog,
                    "Passwords do not match!",
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (password.length() < 6) {
                JOptionPane.showMessageDialog(registerDialog,
                    "Password must be at least 6 characters!",
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!authService.isValidEmail(email)) {
                JOptionPane.showMessageDialog(registerDialog,
                    "Please enter a valid email!",
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!authService.isValidPhone(phone)) {
                JOptionPane.showMessageDialog(registerDialog,
                    "Please enter a valid 10-digit phone number!",
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Register
            Customer customer = new Customer(username, password, fullName, email, phone, address);
            boolean success = authService.registerCustomer(customer);
            
            if (success) {
                JOptionPane.showMessageDialog(registerDialog,
                    "Registration successful! You can now login.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                registerDialog.dispose();
            } else {
                JOptionPane.showMessageDialog(registerDialog,
                    "Registration failed! Username may already exist.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        cancelBtn.addActionListener(e -> registerDialog.dispose());
        
        btnPanel.add(submitBtn);
        btnPanel.add(cancelBtn);
        
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        panel.add(btnPanel, gbc);
        
        registerDialog.add(new JScrollPane(panel));
        registerDialog.setVisible(true);
    }
    
    private void addFormField(JPanel panel, GridBagConstraints gbc, int row, 
                             String label, JComponent field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(new JLabel(label), gbc);
        
        gbc.gridx = 1;
        panel.add(field, gbc);
    }
    
    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(100, 35));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }
}
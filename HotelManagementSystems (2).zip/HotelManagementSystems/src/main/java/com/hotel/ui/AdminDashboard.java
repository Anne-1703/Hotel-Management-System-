package com.hotel.ui;

import com.hotel.models.Admin;
import com.hotel.service.ReportService;
import javax.swing.*;
import java.awt.*;

/**
 * Admin Dashboard - Main interface for administrators
 * COMPLETE VERSION - ALL WARNINGS FIXED
 */
public class AdminDashboard extends JFrame {
    
    private Admin admin;
    private ReportService reportService;
    
    public AdminDashboard(Admin admin) {
        this.admin = admin;
        this.reportService = new ReportService();
        initComponents();
    }
    
    private void initComponents() {
        setTitle("Admin Dashboard - " + admin.getFullName());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1300, 850);
        setLocationRelativeTo(null);
        
        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(236, 240, 241));
        
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(231, 76, 60));
        headerPanel.setPreferredSize(new Dimension(1300, 90));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        headerPanel.setLayout(new BorderLayout());
        
        JPanel leftHeader = new JPanel();
        leftHeader.setOpaque(false);
        leftHeader.setLayout(new BoxLayout(leftHeader, BoxLayout.Y_AXIS));
        
        JLabel welcomeLabel = new JLabel("Admin Control Panel");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 26));
        welcomeLabel.setForeground(Color.WHITE);
        
        JLabel nameLabel = new JLabel(admin.getFullName() + " (ID: " + admin.getAdminId() + ")");
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        nameLabel.setForeground(new Color(236, 240, 241));
        
        leftHeader.add(welcomeLabel);
        leftHeader.add(Box.createVerticalStrut(5));
        leftHeader.add(nameLabel);
        
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(new Color(149, 165, 166));
        logoutBtn.setForeground(Color.BLACK);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 14));
        logoutBtn.setPreferredSize(new Dimension(120, 40));
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new LoginAdminFrame().setVisible(true);
            }
        });
        
        headerPanel.add(leftHeader, BorderLayout.WEST);
        headerPanel.add(logoutBtn, BorderLayout.EAST);
        
        // Center panel with tabs
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));
        tabbedPane.setBackground(Color.WHITE);
        
        // Home tab
        JPanel homePanel = createHomePanel();
        
        // Add all tabs
        tabbedPane.addTab("Dashboard", homePanel);
        tabbedPane.addTab("Check-In/Out", new CheckInOutPage(admin));
        tabbedPane.addTab("Rooms", new RoomManagementPage(admin));
        tabbedPane.addTab("Billing", new BillingPage(admin));
        tabbedPane.addTab("Reports", new ReportPage(admin));
        tabbedPane.addTab("Bookings", new BookingManagementPage(admin));
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JPanel createHomePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        
        // Welcome section
        JPanel welcomePanel = new JPanel();
        welcomePanel.setBackground(Color.WHITE);
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.Y_AXIS));
        
        JLabel titleLabel = new JLabel("Hotel Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 34));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Administrator Control Panel");
        subtitleLabel.setFont(new Font("Arial", Font.ITALIC, 18));
        subtitleLabel.setForeground(new Color(127, 140, 141));
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        welcomePanel.add(Box.createVerticalStrut(20));
        welcomePanel.add(titleLabel);
        welcomePanel.add(Box.createVerticalStrut(10));
        welcomePanel.add(subtitleLabel);
        welcomePanel.add(Box.createVerticalStrut(25));
        
        // Quick stats panel
        JPanel statsPanel = new JPanel(new GridLayout(2, 3, 15, 15));
        statsPanel.setBackground(Color.WHITE);
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));
        
        // FIXED: Call methods directly in createStatCard to avoid unused variable warning
        statsPanel.add(createStatCard("Total Rooms", "Management", 
            new Color(52, 152, 219)));
        statsPanel.add(createStatCard("Occupancy", 
            String.format("%.1f%%", reportService.getOccupancyRate()), 
            new Color(46, 204, 113)));
        statsPanel.add(createStatCard("Revenue", 
            String.format("₹%.0f", reportService.getTotalRevenue()), 
            new Color(155, 89, 182)));
        statsPanel.add(createStatCard("Check-In/Out", "Manage Today", 
            new Color(230, 126, 34)));
        statsPanel.add(createStatCard("Bookings", "View All", 
            new Color(231, 76, 60)));
        statsPanel.add(createStatCard("Generate Bills", "Process Payment", 
            new Color(52, 73, 94)));
        
        // Features panel
        JPanel featuresPanel = new JPanel();
        featuresPanel.setBackground(new Color(236, 240, 241));
        featuresPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        featuresPanel.setLayout(new BoxLayout(featuresPanel, BoxLayout.Y_AXIS));
        
        JLabel featuresTitle = new JLabel("Quick Access Features");
        featuresTitle.setFont(new Font("Arial", Font.BOLD, 16));
        featuresTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel featuresText = new JLabel("<html><center>" +
            "• Check-in and check-out guests efficiently<br>" +
            "• Manage room inventory and pricing<br>" +
            "• Generate bills and process payments<br>" +
            "• View occupancy and financial reports<br>" +
            "• Monitor all bookings and reservations<br>" +
            "• Track revenue and pending payments" +
            "</center></html>");
        featuresText.setFont(new Font("Arial", Font.PLAIN, 14));
        featuresText.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        featuresPanel.add(Box.createVerticalStrut(10));
        featuresPanel.add(featuresTitle);
        featuresPanel.add(Box.createVerticalStrut(10));
        featuresPanel.add(featuresText);
        featuresPanel.add(Box.createVerticalStrut(10));
        
        panel.add(welcomePanel, BorderLayout.NORTH);
        panel.add(statsPanel, BorderLayout.CENTER);
        panel.add(featuresPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(color);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 2),
            BorderFactory.createEmptyBorder(20, 15, 20, 15)
        ));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 22));
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        card.add(titleLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(valueLabel);
        
        return card;
    }
}
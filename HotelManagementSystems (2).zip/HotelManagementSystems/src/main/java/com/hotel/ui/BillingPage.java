package com.hotel.ui;

import com.hotel.models.Admin;
import com.hotel.models.Bill;
import com.hotel.service.BillingService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Billing Page for Admin
 */
public class BillingPage extends JPanel {
    
    @SuppressWarnings("unused")
    private Admin admin;
    private BillingService billingService;
    
    private JTable billTable;
    private DefaultTableModel tableModel;
    private JTextArea billDetailsArea;
    
    public BillingPage(Admin admin) {
        this.admin = admin;
        this.billingService = new BillingService();
        initComponents();
        loadBills();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Billing Management");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        filterPanel.setBackground(Color.WHITE);
        
        JButton allBtn = new JButton("All Bills");
        JButton unpaidBtn = new JButton("Unpaid");
        JButton paidBtn = new JButton("Paid");
        JButton refreshBtn = new JButton("🔄 Refresh");
        
        allBtn.addActionListener(e -> loadAllBills());
        unpaidBtn.addActionListener(e -> loadUnpaidBills());
        paidBtn.addActionListener(e -> loadPaidBills());
        refreshBtn.addActionListener(e -> loadBills());
        
        filterPanel.add(allBtn);
        filterPanel.add(unpaidBtn);
        filterPanel.add(paidBtn);
        filterPanel.add(refreshBtn);
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(filterPanel, BorderLayout.EAST);
        
        // Table
        String[] columns = {"Bill ID", "Booking ID", "Customer", "Room", "Total Amount", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        billTable = new JTable(tableModel);
        billTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        billTable.setRowHeight(25);
        billTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                showBillDetails();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(billTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Bills"));
        
        // Bill details panel
        JPanel detailsPanel = new JPanel(new BorderLayout(5, 5));
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Bill Details"));
        
        billDetailsArea = new JTextArea();
        billDetailsArea.setEditable(false);
        billDetailsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        billDetailsArea.setMargin(new Insets(10, 10, 10, 10));
        
        JScrollPane detailsScroll = new JScrollPane(billDetailsArea);
        
        // Action buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        actionPanel.setBackground(Color.WHITE);
        
        JButton generateBtn = new JButton("Generate Bill");
        generateBtn.setBackground(new Color(52, 152, 219));
        generateBtn.setForeground(Color.RED);
        generateBtn.setFont(new Font("Arial", Font.BOLD, 12));
        generateBtn.setFocusPainted(false);
        generateBtn.addActionListener(e -> generateBill());
        
        JButton processPaymentBtn = new JButton("Process Payment");
        processPaymentBtn.setBackground(new Color(46, 204, 113));
        processPaymentBtn.setForeground(Color.RED);
        processPaymentBtn.setFont(new Font("Arial", Font.BOLD, 12));
        processPaymentBtn.setFocusPainted(false);
        processPaymentBtn.addActionListener(e -> processPayment());
        
        JButton discountBtn = new JButton("Apply Discount");
        discountBtn.setBackground(new Color(243, 156, 18));
        discountBtn.setForeground(Color.RED);
        discountBtn.setFont(new Font("Arial", Font.BOLD, 12));
        discountBtn.setFocusPainted(false);
        discountBtn.addActionListener(e -> applyDiscount());
        
        actionPanel.add(generateBtn);
        actionPanel.add(processPaymentBtn);
        actionPanel.add(discountBtn);
        
        detailsPanel.add(detailsScroll, BorderLayout.CENTER);
        detailsPanel.add(actionPanel, BorderLayout.SOUTH);
        
        // Split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, detailsPanel);
        splitPane.setDividerLocation(550);
        splitPane.setResizeWeight(0.6);
        
        add(headerPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);
    }
    
    private void loadBills() {
        loadAllBills();
    }
    
    private void loadAllBills() {
        tableModel.setRowCount(0);
        List<Bill> bills = billingService.getAllBills();
        populateTable(bills);
    }
    
    private void loadUnpaidBills() {
        tableModel.setRowCount(0);
        List<Bill> bills = billingService.getUnpaidBills();
        populateTable(bills);
    }
    
    private void loadPaidBills() {
        tableModel.setRowCount(0);
        List<Bill> bills = billingService.getPaidBills();
        populateTable(bills);
    }
    
    private void populateTable(List<Bill> bills) {
        for (Bill bill : bills) {
            tableModel.addRow(new Object[]{
                bill.getBillId(),
                bill.getBookingId(),
                bill.getCustomerName(),
                bill.getRoomNumber(),
                String.format("₹%.2f", bill.getTotalAmount()),
                bill.getPaymentStatus()
            });
        }
    }
    
    private void showBillDetails() {
        int selectedRow = billTable.getSelectedRow();
        if (selectedRow < 0) {
            billDetailsArea.setText("");
            return;
        }
        
        int billId = (Integer) tableModel.getValueAt(selectedRow, 0);
        Bill bill = billingService.getBillById(billId);
        
        if (bill != null) {
            billDetailsArea.setText(billingService.getBillBreakdown(bill));
        }
    }
    
    private void generateBill() {
        String input = JOptionPane.showInputDialog(this, 
            "Enter Booking ID to generate bill:", 
            "Generate Bill",
            JOptionPane.QUESTION_MESSAGE);
        
        if (input != null && !input.trim().isEmpty()) {
            try {
                int bookingId = Integer.parseInt(input.trim());
                
                Bill bill = billingService.generateBill(bookingId);
                
                if (bill != null) {
                    JOptionPane.showMessageDialog(this,
                        String.format("Bill generated successfully!\n\nBill ID: %d\nTotal Amount: ₹%.2f",
                            bill.getBillId(), bill.getTotalAmount()),
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                    loadBills();
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Failed to generate bill!\nBooking may not exist or bill already exists.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this,
                    "Invalid booking ID!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void processPayment() {
        int selectedRow = billTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a bill to process payment!",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int billId = (Integer) tableModel.getValueAt(selectedRow, 0);
        Bill bill = billingService.getBillById(billId);
        
        if (bill == null) {
            JOptionPane.showMessageDialog(this, "Bill not found!");
            return;
        }
        
        if (bill.isPaid()) {
            JOptionPane.showMessageDialog(this,
                "This bill is already paid!",
                "Already Paid",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        String[] paymentMethods = {"Cash", "Credit Card", "Debit Card", "UPI", "Net Banking"};
        String method = (String) JOptionPane.showInputDialog(
            this,
            String.format("Process payment for Bill #%d\nAmount: ₹%.2f\n\nSelect payment method:",
                billId, bill.getTotalAmount()),
            "Process Payment",
            JOptionPane.QUESTION_MESSAGE,
            null,
            paymentMethods,
            paymentMethods[0]
        );
        
        if (method != null) {
            boolean success = billingService.processPayment(billId, method);
            
            if (success) {
                JOptionPane.showMessageDialog(this,
                    String.format("Payment processed successfully!\n\nAmount: ₹%.2f\nMethod: %s",
                        bill.getTotalAmount(), method),
                    "Payment Success",
                    JOptionPane.INFORMATION_MESSAGE);
                loadBills();
                showBillDetails();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to process payment!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void applyDiscount() {
        int selectedRow = billTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a bill to apply discount!",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int billId = (Integer) tableModel.getValueAt(selectedRow, 0);
        Bill bill = billingService.getBillById(billId);
        
        if (bill == null) {
            JOptionPane.showMessageDialog(this, "Bill not found!");
            return;
        }
        
        String input = JOptionPane.showInputDialog(this,
            String.format("Enter discount amount for Bill #%d\nSubtotal: ₹%.2f\n\nDiscount Amount:",
                billId, bill.getSubtotal()),
            "Apply Discount",
            JOptionPane.QUESTION_MESSAGE);
        
        if (input != null && !input.trim().isEmpty()) {
            try {
                double discount = Double.parseDouble(input.trim());
                
                if (discount < 0) {
                    JOptionPane.showMessageDialog(this, "Discount cannot be negative!");
                    return;
                }
                
                if (discount > bill.getSubtotal()) {
                    JOptionPane.showMessageDialog(this, "Discount cannot exceed subtotal!");
                    return;
                }
                
                boolean success = billingService.applyDiscount(billId, discount);
                
                if (success) {
                    JOptionPane.showMessageDialog(this,
                        String.format("Discount applied successfully!\n\nDiscount: ₹%.2f\nNew Total: ₹%.2f",
                            discount, bill.getTotalAmount()),
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                    loadBills();
                    showBillDetails();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to apply discount!");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid discount amount!");
            }
        }
    }
}
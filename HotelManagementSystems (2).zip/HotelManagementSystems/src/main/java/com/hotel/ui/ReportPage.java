package com.hotel.ui;

import com.hotel.models.Admin;
import com.hotel.service.ReportService;
import javax.swing.*;
import java.awt.*;

/**
 * Report Page for Admin - Displays occupancy and financial reports
 */
public class ReportPage extends JPanel {
    
    @SuppressWarnings("unused")
    private Admin admin;
    private ReportService reportService;
    
    private JTextArea reportArea;
    
    public ReportPage(Admin admin) {
        this.admin = admin;
        this.reportService = new ReportService();
        initComponents();
        showDailySummary();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Reports & Analytics");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        // Report buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(new Color(236, 240, 241));
        buttonPanel.setBorder(BorderFactory.createTitledBorder("Report Type"));
        
        JButton dailySummaryBtn = new JButton("Daily Summary");
        JButton occupancyBtn = new JButton("Occupancy Report");
        JButton financialBtn = new JButton("Financial Report");
        JButton bookingStatsBtn = new JButton("Booking Statistics");
        JButton roomTypeBtn = new JButton("Room Type Report");
        JButton completeBtn = new JButton("Complete Report");
        JButton refreshBtn = new JButton("Refresh");
        
        dailySummaryBtn.addActionListener(e -> showDailySummary());
        occupancyBtn.addActionListener(e -> showOccupancyReport());
        financialBtn.addActionListener(e -> showFinancialReport());
        bookingStatsBtn.addActionListener(e -> showBookingStatistics());
        roomTypeBtn.addActionListener(e -> showRoomTypeReport());
        completeBtn.addActionListener(e -> showCompleteReport());
        refreshBtn.addActionListener(e -> refreshCurrentReport());
        
        buttonPanel.add(dailySummaryBtn);
        buttonPanel.add(occupancyBtn);
        buttonPanel.add(financialBtn);
        buttonPanel.add(bookingStatsBtn);
        buttonPanel.add(roomTypeBtn);
        buttonPanel.add(completeBtn);
        buttonPanel.add(refreshBtn);
        
        headerPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Report display area
        reportArea = new JTextArea();
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        reportArea.setMargin(new Insets(15, 15, 15, 15));
        reportArea.setBackground(new Color(248, 249, 250));
        
        JScrollPane scrollPane = new JScrollPane(reportArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Report View"));
        
        // Export panel
        JPanel exportPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        exportPanel.setBackground(Color.WHITE);
        
        JButton printBtn = new JButton("Print Report");
        printBtn.setBackground(new Color(52, 152, 219));
        printBtn.setForeground(Color.BLUE);
        printBtn.setFont(new Font("Arial", Font.BOLD, 12));
        printBtn.setFocusPainted(false);
        printBtn.addActionListener(e -> printReport());
        
        JButton copyBtn = new JButton("Copy to Clipboard");
        copyBtn.setBackground(new Color(155, 89, 182));
        copyBtn.setForeground(Color.BLUE);
        copyBtn.setFont(new Font("Arial", Font.BOLD, 12));
        copyBtn.setFocusPainted(false);
        copyBtn.addActionListener(e -> copyToClipboard());
        
        exportPanel.add(printBtn);
        exportPanel.add(copyBtn);
        
        add(headerPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(exportPanel, BorderLayout.SOUTH);
    }
    
    private String currentReportType = "daily";
    
    private void showDailySummary() {
        currentReportType = "daily";
        String report = reportService.generateDailySummary();
        reportArea.setText(report);
        reportArea.setCaretPosition(0);
    }
    
    private void showOccupancyReport() {
        currentReportType = "occupancy";
        String report = reportService.generateOccupancyReport();
        reportArea.setText(report);
        reportArea.setCaretPosition(0);
    }
    
    private void showFinancialReport() {
        currentReportType = "financial";
        String report = reportService.generateFinancialReport();
        reportArea.setText(report);
        reportArea.setCaretPosition(0);
    }
    
    private void showBookingStatistics() {
        currentReportType = "booking";
        String report = reportService.generateBookingStatistics();
        reportArea.setText(report);
        reportArea.setCaretPosition(0);
    }
    
    private void showRoomTypeReport() {
        currentReportType = "roomtype";
        String report = reportService.generateRoomTypeReport();
        reportArea.setText(report);
        reportArea.setCaretPosition(0);
    }
    
    private void showCompleteReport() {
        currentReportType = "complete";
        String report = reportService.generateCompleteReport();
        reportArea.setText(report);
        reportArea.setCaretPosition(0);
    }
    
    private void refreshCurrentReport() {
        switch (currentReportType) {
            case "daily":
                showDailySummary();
                break;
            case "occupancy":
                showOccupancyReport();
                break;
            case "financial":
                showFinancialReport();
                break;
            case "booking":
                showBookingStatistics();
                break;
            case "roomtype":
                showRoomTypeReport();
                break;
            case "complete":
                showCompleteReport();
                break;
            default:
                showDailySummary();
        }
        JOptionPane.showMessageDialog(this,
            "Report refreshed!",
            "Refresh Complete",
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void printReport() {
        try {
            boolean complete = reportArea.print();
            if (complete) {
                JOptionPane.showMessageDialog(this,
                    "Report sent to printer!",
                    "Print Success",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Print cancelled",
                    "Print Cancelled",
                    JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Print failed: " + e.getMessage(),
                "Print Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void copyToClipboard() {
        reportArea.selectAll();
        reportArea.copy();
        reportArea.setCaretPosition(0);
        JOptionPane.showMessageDialog(this,
            "Report copied to clipboard!",
            "Copy Success",
            JOptionPane.INFORMATION_MESSAGE);
    }
}
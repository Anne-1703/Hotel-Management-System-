package com.hotel.ui;

import com.hotel.dao.AddonDAO;
import com.hotel.dao.BookingDAO;
import com.hotel.models.Addon;
import com.hotel.models.Booking;
import com.hotel.models.BookingAddon;
import com.hotel.models.Customer;
import com.hotel.service.AddonService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Addon Page - Customer can add services to their bookings
 */
public class AddonPage extends JPanel {
    
    private Customer customer;
    private AddonService addonService;
    private BookingDAO bookingDAO;
    private AddonDAO addonDAO;
    
    private JComboBox<String> bookingCombo;
    private JTable addonTable;
    private DefaultTableModel addonTableModel;
    private JTable selectedAddonsTable;
    private DefaultTableModel selectedAddonsModel;
    private JLabel totalLabel;
    
    private Booking selectedBooking;
    
    public AddonPage(Customer customer) {
        this.customer = customer;
        this.addonService = new AddonService();
        this.bookingDAO = new BookingDAO();
        this.addonDAO = new AddonDAO();
        initComponents();
        loadCustomerBookings();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Add Services to Booking");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(titleLabel, BorderLayout.NORTH);
        
        // Booking selection
        JPanel bookingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        bookingPanel.setBackground(new Color(236, 240, 241));
        bookingPanel.setBorder(BorderFactory.createTitledBorder("Select Booking"));
        
        JLabel bookingLabel = new JLabel("Your Bookings:");
        bookingCombo = new JComboBox<>();
        bookingCombo.setPreferredSize(new Dimension(300, 30));
        bookingCombo.addActionListener(e -> onBookingSelected());
        
        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.addActionListener(e -> {
            loadCustomerBookings();
            loadBookingAddons();
        });
        
        bookingPanel.add(bookingLabel);
        bookingPanel.add(bookingCombo);
        bookingPanel.add(refreshBtn);
        
        headerPanel.add(bookingPanel, BorderLayout.CENTER);
        
        // Available addons table
        String[] addonColumns = {"Service", "Type", "Price", "Description"};
        addonTableModel = new DefaultTableModel(addonColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        addonTable = new JTable(addonTableModel);
        addonTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        addonTable.setRowHeight(30);
        
        JScrollPane addonScroll = new JScrollPane(addonTable);
        addonScroll.setBorder(BorderFactory.createTitledBorder("Available Services"));
        
        // Add addon panel
        JPanel addPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        addPanel.setBackground(Color.WHITE);
        
        JLabel qtyLabel = new JLabel("Quantity:");
        JSpinner qtySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 50, 1));
        qtySpinner.setPreferredSize(new Dimension(80, 30));
        
        JButton addBtn = new JButton("➕ Add to Booking");
        addBtn.setBackground(new Color(46, 204, 113));
        addBtn.setForeground(Color.BLACK);
        addBtn.setFont(new Font("Arial", Font.BOLD, 12));
        addBtn.setFocusPainted(false);
        addBtn.addActionListener(e -> {
            addAddonToBooking((Integer) qtySpinner.getValue());
            qtySpinner.setValue(1);
        });
        
        addPanel.add(qtyLabel);
        addPanel.add(qtySpinner);
        addPanel.add(addBtn);
        
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.add(addonScroll, BorderLayout.CENTER);
        leftPanel.add(addPanel, BorderLayout.SOUTH);
        
        // Selected addons table
        String[] selectedColumns = {"Service", "Quantity", "Unit Price", "Total Price"};
        selectedAddonsModel = new DefaultTableModel(selectedColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        selectedAddonsTable = new JTable(selectedAddonsModel);
        selectedAddonsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        selectedAddonsTable.setRowHeight(30);
        
        JScrollPane selectedScroll = new JScrollPane(selectedAddonsTable);
        selectedScroll.setBorder(BorderFactory.createTitledBorder("Services Added to This Booking"));
        
        // Remove button
        JPanel removePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        removePanel.setBackground(Color.WHITE);
        
        JButton removeBtn = new JButton("Remove Selected");
        removeBtn.setBackground(new Color(231, 76, 60));
        removeBtn.setForeground(Color.BLACK);
        removeBtn.setFont(new Font("Arial", Font.BOLD, 12));
        removeBtn.setFocusPainted(false);
        removeBtn.addActionListener(e -> removeSelectedAddon());
        
        totalLabel = new JLabel("Total Add-on Charges: ₹0.00");
        totalLabel.setFont(new Font("Arial", Font.BOLD, 16));
        totalLabel.setForeground(new Color(39, 174, 96));
        
        removePanel.add(removeBtn);
        removePanel.add(Box.createHorizontalStrut(20));
        removePanel.add(totalLabel);
        
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(selectedScroll, BorderLayout.CENTER);
        rightPanel.add(removePanel, BorderLayout.SOUTH);
        
        // Split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setDividerLocation(500);
        splitPane.setResizeWeight(0.5);
        
        add(headerPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);
        
        // Load available addons
        loadAvailableAddons();
    }
    
    private void loadCustomerBookings() {
        bookingCombo.removeAllItems();
        List<Booking> bookings = bookingDAO.getBookingsByCustomerId(customer.getCustomerId());
        
        for (Booking booking : bookings) {
            if (booking.getBookingStatus() == Booking.BookingStatus.CONFIRMED || 
                booking.getBookingStatus() == Booking.BookingStatus.CHECKED_IN) {
                String display = String.format("Booking #%d - Room %s (%s to %s)",
                    booking.getBookingId(),
                    booking.getRoomNumber(),
                    booking.getCheckInDate(),
                    booking.getCheckOutDate());
                bookingCombo.addItem(display);
            }
        }
        
        if (bookingCombo.getItemCount() == 0) {
            bookingCombo.addItem("No active bookings");
        }
    }
    
    private void onBookingSelected() {
        String selected = (String) bookingCombo.getSelectedItem();
        if (selected == null || selected.equals("No active bookings")) {
            selectedBooking = null;
            loadBookingAddons();
            return;
        }
        
        try {
            int bookingId = Integer.parseInt(selected.split("#")[1].split(" ")[0]);
            selectedBooking = bookingDAO.getBookingById(bookingId);
            loadBookingAddons();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void loadAvailableAddons() {
        addonTableModel.setRowCount(0);
        List<Addon> addons = addonService.getAllAddons();
        
        for (Addon addon : addons) {
            addonTableModel.addRow(new Object[]{
                addon.getAddonName(),
                addon.getAddonType(),
                String.format("₹%.2f", addon.getPrice()),
                addon.getDescription()
            });
        }
    }
    
    private void loadBookingAddons() {
        selectedAddonsModel.setRowCount(0);
        
        if (selectedBooking == null) {
            totalLabel.setText("Total Add-on Charges: ₹0.00");
            return;
        }
        
        List<BookingAddon> bookingAddons = addonDAO.getBookingAddons(selectedBooking.getBookingId());
        double total = 0.0;
        
        for (BookingAddon ba : bookingAddons) {
            selectedAddonsModel.addRow(new Object[]{
                ba.getAddonName(),
                ba.getQuantity(),
                String.format("₹%.2f", ba.getUnitPrice()),
                String.format("₹%.2f", ba.getTotalPrice())
            });
            total += ba.getTotalPrice();
        }
        
        totalLabel.setText(String.format("Total Add-on Charges: ₹%.2f", total));
    }
    
    private void addAddonToBooking(int quantity) {
        if (selectedBooking == null) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking first!",
                "No Booking Selected",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int selectedRow = addonTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a service to add!",
                "No Service Selected",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String addonName = (String) addonTableModel.getValueAt(selectedRow, 0);
        List<Addon> addons = addonService.getAllAddons();
        Addon selectedAddon = null;
        
        for (Addon addon : addons) {
            if (addon.getAddonName().equals(addonName)) {
                selectedAddon = addon;
                break;
            }
        }
        
        if (selectedAddon == null) {
            JOptionPane.showMessageDialog(this,
                "Service not found!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        boolean success = addonService.addAddonToBooking(
            selectedBooking.getBookingId(),
            selectedAddon.getAddonId(),
            quantity
        );
        
        if (success) {
            JOptionPane.showMessageDialog(this,
                String.format("Added %s (x%d) to booking!\nTotal: ₹%.2f",
                    selectedAddon.getAddonName(),
                    quantity,
                    selectedAddon.getPrice() * quantity),
                "Service Added",
                JOptionPane.INFORMATION_MESSAGE);
            loadBookingAddons();
        } else {
            JOptionPane.showMessageDialog(this,
                "Failed to add service!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void removeSelectedAddon() {
        if (selectedBooking == null) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking first!",
                "No Booking Selected",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int selectedRow = selectedAddonsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a service to remove!",
                "No Service Selected",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        List<BookingAddon> bookingAddons = addonDAO.getBookingAddons(selectedBooking.getBookingId());
        if (selectedRow >= bookingAddons.size()) {
            return;
        }
        
        BookingAddon toRemove = bookingAddons.get(selectedRow);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Remove " + toRemove.getAddonName() + " from booking?",
            "Confirm Removal",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = addonService.removeAddonFromBooking(toRemove.getBookingAddonId());
            
            if (success) {
                JOptionPane.showMessageDialog(this,
                    "Service removed successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                loadBookingAddons();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to remove service!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
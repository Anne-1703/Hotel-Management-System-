package com.hotel.ui;

import com.hotel.models.Customer;
import javax.swing.*;
import java.awt.*;

/**
 * Customer Dashboard - Main interface for customers
 */
public class CustomerDashboard extends JFrame {
    
    private Customer customer;
    
    public CustomerDashboard(Customer customer) {
        this.customer = customer;
        initComponents();
    }
    
    private void initComponents() {
        setTitle("Customer Dashboard - " + customer.getFullName());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 750);
        setLocationRelativeTo(null);
        
        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(236, 240, 241));
        
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(52, 152, 219));
        headerPanel.setPreferredSize(new Dimension(1100, 80));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        headerPanel.setLayout(new BorderLayout());
        
        JLabel welcomeLabel = new JLabel("Welcome, " + customer.getFullName() + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setForeground(Color.WHITE);
        
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightPanel.setOpaque(false);
        
        JLabel idLabel = new JLabel("ID: " + customer.getCustomerId());
        idLabel.setForeground(new Color(236, 240, 241));
        idLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(new Color(231, 76, 60));
        logoutBtn.setForeground(Color.BLACK);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 14));
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new LoginCustomerFrame().setVisible(true);
            }
        });
        
        rightPanel.add(idLabel);
        rightPanel.add(logoutBtn);
        
        headerPanel.add(welcomeLabel, BorderLayout.WEST);
        headerPanel.add(rightPanel, BorderLayout.EAST);
        
        // Center panel with tabs
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));
        tabbedPane.setBackground(Color.WHITE);
        
        // Home tab
        JPanel homePanel = createHomePanel();
        
        // Add all tabs
        tabbedPane.addTab("Home", homePanel);
        tabbedPane.addTab("Book Room", new BookingPage(customer));
        tabbedPane.addTab("My Bookings", new MyBookingsPage(customer));
        tabbedPane.addTab("Add Services", new AddonPage(customer));
        tabbedPane.addTab("Profile", new ProfilePage(customer));
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JPanel createHomePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Welcome section
        JPanel welcomePanel = new JPanel();
        welcomePanel.setBackground(Color.WHITE);
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.Y_AXIS));
        
        JLabel titleLabel = new JLabel("Hotel Management System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Your Comfort is Our Priority");
        subtitleLabel.setFont(new Font("Arial", Font.ITALIC, 18));
        subtitleLabel.setForeground(new Color(127, 140, 141));
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        welcomePanel.add(Box.createVerticalStrut(20));
        welcomePanel.add(titleLabel);
        welcomePanel.add(Box.createVerticalStrut(10));
        welcomePanel.add(subtitleLabel);
        welcomePanel.add(Box.createVerticalStrut(30));
        
        // Features panel
        JPanel featuresPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        featuresPanel.setBackground(Color.WHITE);
        featuresPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        
        featuresPanel.add(createFeatureCard("Book Rooms", 
            "Browse and book from our wide selection of rooms", 
            new Color(52, 152, 219)));
        featuresPanel.add(createFeatureCard("View Bookings", 
            "Check your booking history and status", 
            new Color(46, 204, 113)));
        featuresPanel.add(createFeatureCard("Add Services", 
            "Enhance your stay with our premium services", 
            new Color(155, 89, 182)));
        featuresPanel.add(createFeatureCard("Manage Profile", 
            "Update your personal information", 
            new Color(230, 126, 34)));
        
        // Info panel
        JPanel infoPanel = new JPanel();
        infoPanel.setBackground(new Color(236, 240, 241));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel infoLabel = new JLabel("<html><center>" +
            "ℹ <b>Getting Started:</b><br><br>" +
            "1. Use the 'Book Room' tab to make a new reservation<br>" +
            "2. Add services like meals, taxi, spa from 'Add Services' tab<br>" +
            "3. View all your bookings in 'My Bookings' tab<br>" +
            "4. Update your profile information anytime from 'Profile' tab" +
            "</center></html>");
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        infoPanel.add(infoLabel);
        
        panel.add(welcomePanel, BorderLayout.NORTH);
        panel.add(featuresPanel, BorderLayout.CENTER);
        panel.add(infoPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createFeatureCard(String title, String description, Color color) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(color);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 2),
            BorderFactory.createEmptyBorder(20, 15, 20, 15)
        ));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel descLabel = new JLabel("<html><center>" + description + "</center></html>");
        descLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        descLabel.setForeground(new Color(236, 240, 241));
        descLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        card.add(titleLabel);
        card.add(Box.createVerticalStrut(10));
        card.add(descLabel);
        
        return card;
    }
}
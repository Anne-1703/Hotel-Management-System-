package com.hotel.ui;

import com.hotel.dao.RoomDAO;
import com.hotel.models.Booking;
import com.hotel.models.Customer;
import com.hotel.models.Room;
import com.hotel.service.BookingService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

/**
 * Booking Page for customers to book rooms
 */
public class BookingPage extends JPanel {
    
    private Customer customer;
    private RoomDAO roomDAO;
    private BookingService bookingService;
    
    private JComboBox<String> roomTypeCombo;
    private JSpinner checkInSpinner;
    private JSpinner checkOutSpinner;
    private JTable roomTable;
    private DefaultTableModel tableModel;
    private JLabel totalNightsLabel;
    private JLabel estimatedCostLabel;
    
    private Room selectedRoom;
    
    public BookingPage(Customer customer) {
        this.customer = customer;
        this.roomDAO = new RoomDAO();
        this.bookingService = new BookingService();
        initComponents();
        loadAvailableRooms();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Book a Room");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        headerPanel.add(titleLabel, BorderLayout.NORTH);
        
        // Filter panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        filterPanel.setBackground(new Color(236, 240, 241));
        filterPanel.setBorder(BorderFactory.createTitledBorder("Search Rooms"));
        
        JLabel roomTypeLabel = new JLabel("Room Type:");
        roomTypeCombo = new JComboBox<>(new String[]{"ALL", "SINGLE", "DOUBLE", "SUITE", "DELUXE"});
        roomTypeCombo.addActionListener(e -> filterRooms());
        
        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.addActionListener(e -> loadAvailableRooms());
        
        filterPanel.add(roomTypeLabel);
        filterPanel.add(roomTypeCombo);
        filterPanel.add(refreshBtn);
        
        headerPanel.add(filterPanel, BorderLayout.CENTER);
        
        // Room table
        String[] columns = {"Room No", "Type", "Price/Night", "Capacity", "Description", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        roomTable = new JTable(tableModel);
        roomTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        roomTable.setRowHeight(30);
        roomTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                onRoomSelected();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(roomTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Available Rooms"));
        
        // Booking details panel
        JPanel bookingPanel = new JPanel(new GridBagLayout());
        bookingPanel.setBackground(Color.WHITE);
        bookingPanel.setBorder(BorderFactory.createTitledBorder("Booking Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Check-in date
        JLabel checkInLabel = new JLabel("Check-in Date:");
        SpinnerDateModel checkInModel = new SpinnerDateModel();
        checkInSpinner = new JSpinner(checkInModel);
        JSpinner.DateEditor checkInEditor = new JSpinner.DateEditor(checkInSpinner, "yyyy-MM-dd");
        checkInSpinner.setEditor(checkInEditor);
        checkInSpinner.setValue(java.util.Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()));
        checkInSpinner.addChangeListener(e -> calculateCost());
        
        // Check-out date
        JLabel checkOutLabel = new JLabel("Check-out Date:");
        SpinnerDateModel checkOutModel = new SpinnerDateModel();
        checkOutSpinner = new JSpinner(checkOutModel);
        JSpinner.DateEditor checkOutEditor = new JSpinner.DateEditor(checkOutSpinner, "yyyy-MM-dd");
        checkOutSpinner.setEditor(checkOutEditor);
        checkOutSpinner.setValue(java.util.Date.from(LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant()));
        checkOutSpinner.addChangeListener(e -> calculateCost());
        
        // Total nights
        totalNightsLabel = new JLabel("Total Nights: 1");
        totalNightsLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Estimated cost
        estimatedCostLabel = new JLabel("Estimated Cost: ₹0.00");
        estimatedCostLabel.setFont(new Font("Arial", Font.BOLD, 16));
        estimatedCostLabel.setForeground(new Color(39, 174, 96));
        
        // Book button
        JButton bookBtn = new JButton("Book Now");
        bookBtn.setBackground(new Color(46, 204, 113));
        bookBtn.setForeground(Color.BLUE);
        bookBtn.setFont(new Font("Arial", Font.BOLD, 14));
        bookBtn.setFocusPainted(false);
        bookBtn.setPreferredSize(new Dimension(150, 40));
        bookBtn.addActionListener(e -> handleBooking());
        
        // Add components
        gbc.gridx = 0; gbc.gridy = 0;
        bookingPanel.add(checkInLabel, gbc);
        gbc.gridx = 1;
        bookingPanel.add(checkInSpinner, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        bookingPanel.add(checkOutLabel, gbc);
        gbc.gridx = 1;
        bookingPanel.add(checkOutSpinner, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        bookingPanel.add(totalNightsLabel, gbc);
        
        gbc.gridy = 3;
        bookingPanel.add(estimatedCostLabel, gbc);
        
        gbc.gridy = 4;
        gbc.insets = new Insets(15, 10, 8, 10);
        bookingPanel.add(bookBtn, gbc);
        
        // Right panel for booking details
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(Color.WHITE);
        rightPanel.add(bookingPanel, BorderLayout.NORTH);
        
        // Split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, rightPanel);
        splitPane.setDividerLocation(600);
        splitPane.setResizeWeight(0.7);
        
        add(headerPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);
    }
    
    private void loadAvailableRooms() {
        List<Room> rooms = roomDAO.getAvailableRooms();
        updateTable(rooms);
    }
    
    private void filterRooms() {
        String selectedType = (String) roomTypeCombo.getSelectedItem();
        
        if ("ALL".equals(selectedType)) {
            loadAvailableRooms();
        } else {
            Room.RoomType roomType = Room.RoomType.valueOf(selectedType);
            List<Room> rooms = roomDAO.getRoomsByType(roomType);
            updateTable(rooms);
        }
    }
    
    private void updateTable(List<Room> rooms) {
        tableModel.setRowCount(0);
        for (Room room : rooms) {
            tableModel.addRow(new Object[]{
                room.getRoomNumber(),
                room.getRoomType(),
                String.format("₹%.2f", room.getBasePrice()),
                room.getCapacity(),
                room.getDescription(),
                room.getStatus()
            });
        }
    }
    
    private void onRoomSelected() {
        int selectedRow = roomTable.getSelectedRow();
        if (selectedRow >= 0) {
            String roomNumber = (String) tableModel.getValueAt(selectedRow, 0);
            selectedRoom = roomDAO.getRoomByNumber(roomNumber);
            calculateCost();
        }
    }
    
    private void calculateCost() {
        if (selectedRoom == null) {
            totalNightsLabel.setText("Total Nights: -");
            estimatedCostLabel.setText("Estimated Cost: -");
            return;
        }
        
        try {
            java.util.Date checkInDate = (java.util.Date) checkInSpinner.getValue();
            java.util.Date checkOutDate = (java.util.Date) checkOutSpinner.getValue();
            
            LocalDate checkIn = checkInDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate checkOut = checkOutDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            
            long nights = java.time.temporal.ChronoUnit.DAYS.between(checkIn, checkOut);
            
            if (nights <= 0) {
                totalNightsLabel.setText("Total Nights: Invalid");
                estimatedCostLabel.setText("Estimated Cost: Invalid dates");
                return;
            }
            
            Date sqlCheckIn = Date.valueOf(checkIn);
            Date sqlCheckOut = Date.valueOf(checkOut);
            
            double cost = bookingService.calculateRoomCharges(selectedRoom.getRoomId(), sqlCheckIn, sqlCheckOut);
            
            totalNightsLabel.setText("Total Nights: " + nights);
            estimatedCostLabel.setText(String.format("Estimated Cost: ₹%.2f", cost));
            
        } catch (Exception e) {
            e.printStackTrace();
            totalNightsLabel.setText("Total Nights: Error");
            estimatedCostLabel.setText("Estimated Cost: -");
        }
    }
    
    private void handleBooking() {
        if (selectedRoom == null) {
            JOptionPane.showMessageDialog(this,
                "Please select a room first!",
                "No Room Selected",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            java.util.Date checkInDate = (java.util.Date) checkInSpinner.getValue();
            java.util.Date checkOutDate = (java.util.Date) checkOutSpinner.getValue();
            
            LocalDate checkIn = checkInDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate checkOut = checkOutDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            
            if (checkIn.isBefore(LocalDate.now())) {
                JOptionPane.showMessageDialog(this,
                    "Check-in date cannot be in the past!",
                    "Invalid Date",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!checkOut.isAfter(checkIn)) {
                JOptionPane.showMessageDialog(this,
                    "Check-out date must be after check-in date!",
                    "Invalid Date",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            Date sqlCheckIn = Date.valueOf(checkIn);
            Date sqlCheckOut = Date.valueOf(checkOut);
            
            // Calculate cost for confirmation
            double cost = bookingService.calculateRoomCharges(selectedRoom.getRoomId(), sqlCheckIn, sqlCheckOut);
            
            int confirm = JOptionPane.showConfirmDialog(this,
                String.format("Confirm Booking?\n\nRoom: %s (%s)\nCheck-in: %s\nCheck-out: %s\nTotal Cost: ₹%.2f\n\nProceed?",
                    selectedRoom.getRoomNumber(),
                    selectedRoom.getRoomType(),
                    checkIn,
                    checkOut,
                    cost),
                "Confirm Booking",
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                Booking booking = bookingService.createBooking(
                    customer.getCustomerId(),
                    selectedRoom.getRoomId(),
                    sqlCheckIn,
                    sqlCheckOut
                );
                
                if (booking != null) {
                    JOptionPane.showMessageDialog(this,
                        String.format("Booking successful!\n\nBooking ID: %d\nTotal Cost: ₹%.2f\n\nYou can add services from the 'Add Services' tab.",
                            booking.getBookingId(), cost),
                        "Booking Confirmed",
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    // Reset and refresh
                    loadAvailableRooms();
                    selectedRoom = null;
                    roomTable.clearSelection();
                    calculateCost();
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Failed to create booking!",
                        "Booking Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error processing booking: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}
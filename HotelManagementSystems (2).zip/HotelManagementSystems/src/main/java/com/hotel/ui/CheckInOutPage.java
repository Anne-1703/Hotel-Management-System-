package com.hotel.ui;

import com.hotel.models.Admin;
import com.hotel.models.Booking;
import com.hotel.service.BookingService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Check-In/Check-Out Page for Admin
 * ALL WARNINGS FIXED
 */
public class CheckInOutPage extends JPanel {
    
    @SuppressWarnings("unused")
    private Admin admin;
    private BookingService bookingService;
    
    private JTable checkInTable;
    private DefaultTableModel checkInModel;
    private JTable checkOutTable;
    private DefaultTableModel checkOutModel;
    
    public CheckInOutPage(Admin admin) {
        this.admin = admin;
        this.bookingService = new BookingService();
        initComponents();
        loadData();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Check-In / Check-Out Management");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        
        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.setFont(new Font("Arial", Font.BOLD, 12));
        refreshBtn.addActionListener(e -> loadData());
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(refreshBtn, BorderLayout.EAST);
        
        // Split pane for check-in and check-out
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setDividerLocation(250);
        splitPane.setResizeWeight(0.5);
        
        // Check-in panel
        JPanel checkInPanel = createCheckInPanel();
        
        // Check-out panel
        JPanel checkOutPanel = createCheckOutPanel();
        
        splitPane.setTopComponent(checkInPanel);
        splitPane.setBottomComponent(checkOutPanel);
        
        add(headerPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);
    }
    
    private JPanel createCheckInPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder("Today's Check-Ins"));
        
        // Table
        String[] columns = {"Booking ID", "Customer", "Room", "Check-in Date", "Status"};
        checkInModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        checkInTable = new JTable(checkInModel);
        checkInTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        checkInTable.setRowHeight(25);
        
        JScrollPane scrollPane = new JScrollPane(checkInTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setBackground(Color.WHITE);
        
        JButton checkInBtn = new JButton("Check-In");
        checkInBtn.setBackground(new Color(46, 204, 113));
        checkInBtn.setForeground(Color.BLACK);
        checkInBtn.setFont(new Font("Arial", Font.BOLD, 12));
        checkInBtn.setFocusPainted(false);
        checkInBtn.addActionListener(e -> handleCheckIn());
        
        JButton viewDetailsBtn = new JButton("View Details");
        viewDetailsBtn.setBackground(new Color(52, 152, 219));
        viewDetailsBtn.setForeground(Color.BLACK);
        viewDetailsBtn.setFont(new Font("Arial", Font.BOLD, 12));
        viewDetailsBtn.setFocusPainted(false);
        viewDetailsBtn.addActionListener(e -> showCheckInDetails());
        
        buttonPanel.add(checkInBtn);
        buttonPanel.add(viewDetailsBtn);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createCheckOutPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder("Today's Check-Outs"));
        
        // Table
        String[] columns = {"Booking ID", "Customer", "Room", "Check-out Date", "Status"};
        checkOutModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        checkOutTable = new JTable(checkOutModel);
        checkOutTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        checkOutTable.setRowHeight(25);
        
        JScrollPane scrollPane = new JScrollPane(checkOutTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setBackground(Color.WHITE);
        
        JButton checkOutBtn = new JButton("Check-Out");
        checkOutBtn.setBackground(new Color(231, 76, 60));
        checkOutBtn.setForeground(Color.BLACK);
        checkOutBtn.setFont(new Font("Arial", Font.BOLD, 12));
        checkOutBtn.setFocusPainted(false);
        checkOutBtn.addActionListener(e -> handleCheckOut());
        
        JButton viewDetailsBtn = new JButton("View Details");
        viewDetailsBtn.setBackground(new Color(52, 152, 219));
        viewDetailsBtn.setForeground(Color.BLACK);
        viewDetailsBtn.setFont(new Font("Arial", Font.BOLD, 12));
        viewDetailsBtn.setFocusPainted(false);
        viewDetailsBtn.addActionListener(e -> showCheckOutDetails());
        
        buttonPanel.add(checkOutBtn);
        buttonPanel.add(viewDetailsBtn);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private void loadData() {
        loadCheckIns();
        loadCheckOuts();
    }
    
    private void loadCheckIns() {
        checkInModel.setRowCount(0);
        List<Booking> checkIns = bookingService.getTodayCheckIns();
        
        for (Booking booking : checkIns) {
            checkInModel.addRow(new Object[]{
                booking.getBookingId(),
                booking.getCustomerName(),
                booking.getRoomNumber(),
                booking.getCheckInDate(),
                booking.getBookingStatus()
            });
        }
    }
    
    private void loadCheckOuts() {
        checkOutModel.setRowCount(0);
        List<Booking> checkOuts = bookingService.getTodayCheckOuts();
        
        for (Booking booking : checkOuts) {
            checkOutModel.addRow(new Object[]{
                booking.getBookingId(),
                booking.getCustomerName(),
                booking.getRoomNumber(),
                booking.getCheckOutDate(),
                booking.getBookingStatus()
            });
        }
    }
    
    private void handleCheckIn() {
        int selectedRow = checkInTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking to check-in!",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookingId = (Integer) checkInModel.getValueAt(selectedRow, 0);
        String customerName = (String) checkInModel.getValueAt(selectedRow, 1);
        String room = (String) checkInModel.getValueAt(selectedRow, 2);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            String.format("Check-in customer?\n\nBooking ID: %d\nCustomer: %s\nRoom: %s",
                bookingId, customerName, room),
            "Confirm Check-In",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = bookingService.checkIn(bookingId);
            
            if (success) {
                JOptionPane.showMessageDialog(this,
                    "Check-in successful!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                loadData();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Check-in failed!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void handleCheckOut() {
        int selectedRow = checkOutTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking to check-out!",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookingId = (Integer) checkOutModel.getValueAt(selectedRow, 0);
        String customerName = (String) checkOutModel.getValueAt(selectedRow, 1);
        String room = (String) checkOutModel.getValueAt(selectedRow, 2);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            String.format("Check-out customer?\n\nBooking ID: %d\nCustomer: %s\nRoom: %s\n\nNote: Make sure bill is generated and paid!",
                bookingId, customerName, room),
            "Confirm Check-Out",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = bookingService.checkOut(bookingId);
            
            if (success) {
                JOptionPane.showMessageDialog(this,
                    "Check-out successful!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                loadData();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Check-out failed!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void showCheckInDetails() {
        int selectedRow = checkInTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking!",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookingId = (Integer) checkInModel.getValueAt(selectedRow, 0);
        showBookingDetails(bookingId);
    }
    
    private void showCheckOutDetails() {
        int selectedRow = checkOutTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking!",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookingId = (Integer) checkOutModel.getValueAt(selectedRow, 0);
        showBookingDetails(bookingId);
    }
    
    private void showBookingDetails(int bookingId) {
        Booking booking = bookingService.getBookingById(bookingId);
        
        if (booking == null) {
            JOptionPane.showMessageDialog(this,
                "Unable to load booking details!",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String details = String.format(
            "Booking Details\n\n" +
            "Booking ID: %d\n" +
            "Customer: %s\n" +
            "Room: %s (%s)\n" +
            "Check-in: %s\n" +
            "Check-out: %s\n" +
            "Total Nights: %d\n" +
            "Status: %s\n" +
            "Booked On: %s",
            booking.getBookingId(),
            booking.getCustomerName(),
            booking.getRoomNumber(),
            booking.getRoomType(),
            booking.getCheckInDate(),
            booking.getCheckOutDate(),
            booking.getTotalNights(),
            booking.getBookingStatus(),
            booking.getBookingDate()
        );
        
        JOptionPane.showMessageDialog(this,
            details,
            "Booking Details",
            JOptionPane.INFORMATION_MESSAGE);
    }
}
package com.hotel.ui;

import com.hotel.models.Admin;
import com.hotel.models.Booking;
import com.hotel.service.BookingService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Booking Management Page for Admin
 */
public class BookingManagementPage extends JPanel {
    
    @SuppressWarnings("unused")
    private Admin admin;
    private BookingService bookingService;
    
    private JTable bookingTable;
    private DefaultTableModel tableModel;
    private JTextArea detailsArea;
    
    public BookingManagementPage(Admin admin) {
        this.admin = admin;
        this.bookingService = new BookingService();
        initComponents();
        loadAllBookings();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel("Booking Management");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        filterPanel.setBackground(Color.WHITE);
        
        JButton allBtn = new JButton("All");
        JButton activeBtn = new JButton("Active");
        JButton confirmedBtn = new JButton("Confirmed");
        JButton checkedInBtn = new JButton("Checked-In");
        JButton refreshBtn = new JButton("🔄 Refresh");
        
        allBtn.addActionListener(e -> loadAllBookings());
        activeBtn.addActionListener(e -> loadActiveBookings());
        confirmedBtn.addActionListener(e -> loadConfirmedBookings());
        checkedInBtn.addActionListener(e -> loadCheckedInBookings());
        refreshBtn.addActionListener(e -> loadAllBookings());
        
        filterPanel.add(allBtn);
        filterPanel.add(activeBtn);
        filterPanel.add(confirmedBtn);
        filterPanel.add(checkedInBtn);
        filterPanel.add(refreshBtn);
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(filterPanel, BorderLayout.EAST);
        
        // Table
        String[] columns = {"Booking ID", "Customer", "Room", "Check-in", "Check-out", "Nights", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        bookingTable = new JTable(tableModel);
        bookingTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        bookingTable.setRowHeight(25);
        bookingTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                showBookingDetails();
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(bookingTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("All Bookings"));
        
        // Details panel
        JPanel detailsPanel = new JPanel(new BorderLayout(5, 5));
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Booking Details"));
        
        detailsArea = new JTextArea();
        detailsArea.setEditable(false);
        detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        detailsArea.setMargin(new Insets(10, 10, 10, 10));
        
        JScrollPane detailsScroll = new JScrollPane(detailsArea);
        
        // Action buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        actionPanel.setBackground(Color.WHITE);
        
        JButton viewBtn = new JButton("View Full Details");
        viewBtn.setBackground(new Color(52, 152, 219));
        viewBtn.setForeground(Color.BLUE);
        viewBtn.setFont(new Font("Arial", Font.BOLD, 12));
        viewBtn.setFocusPainted(false);
        viewBtn.addActionListener(e -> showFullBookingDetails());
        
        JButton cancelBtn = new JButton("Cancel Booking");
        cancelBtn.setBackground(new Color(231, 76, 60));
        cancelBtn.setForeground(Color.BLUE);
        cancelBtn.setFont(new Font("Arial", Font.BOLD, 12));
        cancelBtn.setFocusPainted(false);
        cancelBtn.addActionListener(e -> cancelBooking());
        
        actionPanel.add(viewBtn);
        actionPanel.add(cancelBtn);
        
        detailsPanel.add(detailsScroll, BorderLayout.CENTER);
        detailsPanel.add(actionPanel, BorderLayout.SOUTH);
        
        // Split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, detailsPanel);
        splitPane.setDividerLocation(650);
        splitPane.setResizeWeight(0.65);
        
        add(headerPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);
    }
    
    private void loadAllBookings() {
        tableModel.setRowCount(0);
        List<Booking> bookings = bookingService.getAllBookings();
        populateTable(bookings);
    }
    
    private void loadActiveBookings() {
        tableModel.setRowCount(0);
        List<Booking> bookings = bookingService.getActiveBookings();
        populateTable(bookings);
    }
    
    private void loadConfirmedBookings() {
        tableModel.setRowCount(0);
        List<Booking> bookings = bookingService.getAllBookings();
        bookings.removeIf(b -> b.getBookingStatus() != Booking.BookingStatus.CONFIRMED);
        populateTable(bookings);
    }
    
    private void loadCheckedInBookings() {
        tableModel.setRowCount(0);
        List<Booking> bookings = bookingService.getAllBookings();
        bookings.removeIf(b -> b.getBookingStatus() != Booking.BookingStatus.CHECKED_IN);
        populateTable(bookings);
    }
    
    private void populateTable(List<Booking> bookings) {
        for (Booking booking : bookings) {
            tableModel.addRow(new Object[]{
                booking.getBookingId(),
                booking.getCustomerName(),
                booking.getRoomNumber(),
                booking.getCheckInDate(),
                booking.getCheckOutDate(),
                booking.getTotalNights(),
                booking.getBookingStatus()
            });
        }
    }
    
    private void showBookingDetails() {
        int selectedRow = bookingTable.getSelectedRow();
        if (selectedRow < 0) {
            detailsArea.setText("");
            return;
        }
        
        int bookingId = (Integer) tableModel.getValueAt(selectedRow, 0);
        Booking booking = bookingService.getBookingById(bookingId);
        
        if (booking == null) {
            detailsArea.setText("Unable to load booking details.");
            return;
        }
        
        StringBuilder details = new StringBuilder();
        details.append("═══════════════════════════════════════\n");
        details.append("         BOOKING SUMMARY\n");
        details.append("═══════════════════════════════════════\n\n");
        details.append(String.format("Booking ID:      %d\n", booking.getBookingId()));
        details.append(String.format("Customer:        %s\n", booking.getCustomerName()));
        details.append(String.format("Room:            %s (%s)\n", booking.getRoomNumber(), booking.getRoomType()));
        details.append(String.format("Check-in:        %s\n", booking.getCheckInDate()));
        details.append(String.format("Check-out:       %s\n", booking.getCheckOutDate()));
        details.append(String.format("Total Nights:    %d\n", booking.getTotalNights()));
        details.append(String.format("Status:          %s\n", booking.getBookingStatus()));
        details.append(String.format("Booked On:       %s\n", booking.getBookingDate()));
        details.append("\n═══════════════════════════════════════\n");
        
        detailsArea.setText(details.toString());
    }
    
    private void showFullBookingDetails() {
        int selectedRow = bookingTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking!",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookingId = (Integer) tableModel.getValueAt(selectedRow, 0);
        Booking booking = bookingService.getBookingById(bookingId);
        
        if (booking == null) {
            JOptionPane.showMessageDialog(this, "Booking not found!");
            return;
        }
        
        String details = String.format(
            "════════════════════════════════════════\n" +
            "        COMPLETE BOOKING DETAILS\n" +
            "════════════════════════════════════════\n\n" +
            "Booking ID:        %d\n" +
            "Customer ID:       %d\n" +
            "Customer Name:     %s\n" +
            "Room ID:           %d\n" +
            "Room Number:       %s\n" +
            "Room Type:         %s\n" +
            "Check-in Date:     %s\n" +
            "Check-out Date:    %s\n" +
            "Total Nights:      %d\n" +
            "Booking Status:    %s\n" +
            "Booking Date:      %s\n\n" +
            "════════════════════════════════════════",
            booking.getBookingId(),
            booking.getCustomerId(),
            booking.getCustomerName(),
            booking.getRoomId(),
            booking.getRoomNumber(),
            booking.getRoomType(),
            booking.getCheckInDate(),
            booking.getCheckOutDate(),
            booking.getTotalNights(),
            booking.getBookingStatus(),
            booking.getBookingDate()
        );
        
        JOptionPane.showMessageDialog(this,
            details,
            "Complete Booking Details",
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void cancelBooking() {
        int selectedRow = bookingTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this,
                "Please select a booking to cancel!",
                "No Selection",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookingId = (Integer) tableModel.getValueAt(selectedRow, 0);
        Booking booking = bookingService.getBookingById(bookingId);
        
        if (booking == null) {
            JOptionPane.showMessageDialog(this, "Booking not found!");
            return;
        }
        
        if (booking.getBookingStatus() == Booking.BookingStatus.CANCELLED) {
            JOptionPane.showMessageDialog(this,
                "This booking is already cancelled!",
                "Already Cancelled",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        if (booking.getBookingStatus() == Booking.BookingStatus.CHECKED_IN ||
            booking.getBookingStatus() == Booking.BookingStatus.CHECKED_OUT) {
            JOptionPane.showMessageDialog(this,
                "Cannot cancel a booking that is checked-in or completed!",
                "Cannot Cancel",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            String.format("Cancel booking #%d?\n\nCustomer: %s\nRoom: %s\nCheck-in: %s",
                bookingId, booking.getCustomerName(), booking.getRoomNumber(), booking.getCheckInDate()),
            "Confirm Cancellation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = bookingService.cancelBooking(bookingId);
            
            if (success) {
                JOptionPane.showMessageDialog(this,
                    "Booking cancelled successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
                loadAllBookings();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Failed to cancel booking!",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
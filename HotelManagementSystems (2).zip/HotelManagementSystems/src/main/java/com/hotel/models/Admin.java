package com.hotel.models;

import java.sql.Timestamp;

/**
 * Admin Model Class
 * Represents an administrator user in the system
 */
public class Admin {
    
    // Fields
    private int adminId;
    private String username;
    private String password;
    private String fullName;
    private String email;
    private Timestamp createdAt;
    
    // Constructors
    public Admin() {
    }
    
    public Admin(int adminId, String username, String fullName, String email) {
        this.adminId = adminId;
        this.username = username;
        this.fullName = fullName;
        this.email = email;
    }
    
    public Admin(String username, String password, String fullName, String email) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.email = email;
    }
    
    // Getters and Setters
    public int getAdminId() {
        return adminId;
    }
    
    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    // Helper Methods
    public String getDisplayName() {
        return fullName + " (Admin)";
    }
    
    @Override
    public String toString() {
        return String.format("Admin[%d, %s, %s, %s]", 
            adminId, username, fullName, email);
    }
}
package com.hotel.models;

import java.sql.Timestamp;

/**
 * Bill Model Class
 * Represents a billing record for a booking
 */
public class Bill {
    
    // Payment Status Enum
    public enum PaymentStatus {
        UNPAID, PAID, PARTIAL
    }
    
    // Fields
    private int billId;
    private int bookingId;
    private double roomCharges;
    private double addonCharges;
    private double taxAmount;
    private double discountAmount;
    private double totalAmount;
    private PaymentStatus paymentStatus;
    private String paymentMethod;
    private Timestamp billDate;
    
    // Additional fields for display
    private String customerName;
    private String roomNumber;
    
    // Tax rate constant (18% GST)
    public static final double TAX_RATE = 0.18;
    
    // Constructors
    public Bill() {
        this.paymentStatus = PaymentStatus.UNPAID;
        this.discountAmount = 0.0;
        this.addonCharges = 0.0;
    }
    
    public Bill(int bookingId, double roomCharges, double addonCharges) {
        this.bookingId = bookingId;
        this.roomCharges = roomCharges;
        this.addonCharges = addonCharges;
        this.discountAmount = 0.0;
        this.paymentStatus = PaymentStatus.UNPAID;
        calculateTotal();
    }
    
    // Getters and Setters
    public int getBillId() {
        return billId;
    }
    
    public void setBillId(int billId) {
        this.billId = billId;
    }
    
    public int getBookingId() {
        return bookingId;
    }
    
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }
    
    public double getRoomCharges() {
        return roomCharges;
    }
    
    public void setRoomCharges(double roomCharges) {
        this.roomCharges = roomCharges;
        calculateTotal();
    }
    
    public double getAddonCharges() {
        return addonCharges;
    }
    
    public void setAddonCharges(double addonCharges) {
        this.addonCharges = addonCharges;
        calculateTotal();
    }
    
    public double getTaxAmount() {
        return taxAmount;
    }
    
    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }
    
    public double getDiscountAmount() {
        return discountAmount;
    }
    
    public void setDiscountAmount(double discountAmount) {
        this.discountAmount = discountAmount;
        calculateTotal();
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }
    
    public void setPaymentStatus(PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
    
    public String getPaymentMethod() {
        return paymentMethod;
    }
    
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    
    public Timestamp getBillDate() {
        return billDate;
    }
    
    public void setBillDate(Timestamp billDate) {
        this.billDate = billDate;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    
    public String getRoomNumber() {
        return roomNumber;
    }
    
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    
    // Helper Methods
    public void calculateTotal() {
        double subtotal = roomCharges + addonCharges - discountAmount;
        this.taxAmount = subtotal * TAX_RATE;
        this.totalAmount = subtotal + taxAmount;
    }
    
    public double getSubtotal() {
        return roomCharges + addonCharges;
    }
    
    public boolean isPaid() {
        return paymentStatus == PaymentStatus.PAID;
    }
    
    @Override
    public String toString() {
        return String.format("Bill[%d, Booking:%d, Room:₹%.2f, Addons:₹%.2f, Total:₹%.2f, %s]", 
            billId, bookingId, roomCharges, addonCharges, totalAmount, paymentStatus);
    }
}
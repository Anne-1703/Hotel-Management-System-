package com.hotel.models;

import java.sql.Timestamp;

/**
 * BookingAddon Model Class
 * Represents the relationship between bookings and addons (junction table)
 */
public class BookingAddon {
    
    // Fields
    private int bookingAddonId;
    private int bookingId;
    private int addonId;
    private int quantity;
    private double totalPrice;
    private Timestamp addedDate;
    
    // Additional fields for display
    private String addonName;
    private String addonType;
    private double unitPrice;
    
    // Constructors
    public BookingAddon() {
        this.quantity = 1;
    }
    
    public BookingAddon(int bookingId, int addonId, int quantity, double totalPrice) {
        this.bookingId = bookingId;
        this.addonId = addonId;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
    }
    
    // Getters and Setters
    public int getBookingAddonId() {
        return bookingAddonId;
    }
    
    public void setBookingAddonId(int bookingAddonId) {
        this.bookingAddonId = bookingAddonId;
    }
    
    public int getBookingId() {
        return bookingId;
    }
    
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }
    
    public int getAddonId() {
        return addonId;
    }
    
    public void setAddonId(int addonId) {
        this.addonId = addonId;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public double getTotalPrice() {
        return totalPrice;
    }
    
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    
    public Timestamp getAddedDate() {
        return addedDate;
    }
    
    public void setAddedDate(Timestamp addedDate) {
        this.addedDate = addedDate;
    }
    
    public String getAddonName() {
        return addonName;
    }
    
    public void setAddonName(String addonName) {
        this.addonName = addonName;
    }
    
    public String getAddonType() {
        return addonType;
    }
    
    public void setAddonType(String addonType) {
        this.addonType = addonType;
    }
    
    public double getUnitPrice() {
        return unitPrice;
    }
    
    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }
    
    // Helper Methods
    public void calculateTotalPrice(double pricePerUnit) {
        this.totalPrice = pricePerUnit * quantity;
    }
    
    @Override
    public String toString() {
        return String.format("BookingAddon[Booking:%d, Addon:%d, Qty:%d, Total:₹%.2f]", 
            bookingId, addonId, quantity, totalPrice);
    }
}
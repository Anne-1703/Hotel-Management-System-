package com.hotel.models;

/**
 * Addon Model Class
 * Represents additional services available for bookings
 */
public class Addon {
    
    // Addon Type Enum
    public enum AddonType {
        MEAL, TAXI, LAUNDRY, SPA, OTHER
    }
    
    // Fields
    private int addonId;
    private String addonName;
    private AddonType addonType;
    private double price;
    private String description;
    private boolean isActive;
    
    // Constructors
    public Addon() {
        this.isActive = true;
    }
    
    public Addon(int addonId, String addonName, AddonType addonType, 
                 double price, String description, boolean isActive) {
        this.addonId = addonId;
        this.addonName = addonName;
        this.addonType = addonType;
        this.price = price;
        this.description = description;
        this.isActive = isActive;
    }
    
    public Addon(String addonName, AddonType addonType, double price, String description) {
        this.addonName = addonName;
        this.addonType = addonType;
        this.price = price;
        this.description = description;
        this.isActive = true;
    }
    
    // Getters and Setters
    public int getAddonId() {
        return addonId;
    }
    
    public void setAddonId(int addonId) {
        this.addonId = addonId;
    }
    
    public String getAddonName() {
        return addonName;
    }
    
    public void setAddonName(String addonName) {
        this.addonName = addonName;
    }
    
    public AddonType getAddonType() {
        return addonType;
    }
    
    public void setAddonType(AddonType addonType) {
        this.addonType = addonType;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    // Helper Methods
    public String getDisplayName() {
        return addonName + " - ₹" + String.format("%.2f", price);
    }
    
    public double calculateTotal(int quantity) {
        return price * quantity;
    }
    
    @Override
    public String toString() {
        return String.format("Addon[%d, %s, %s, ₹%.2f, Active:%s]", 
            addonId, addonName, addonType, price, isActive);
    }
}
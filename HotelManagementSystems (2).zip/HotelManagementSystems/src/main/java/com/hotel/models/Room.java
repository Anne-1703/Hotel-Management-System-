package com.hotel.models;

import java.sql.Timestamp;

/**
 * Room Model Class
 * Represents a hotel room with all its properties
 */
public class Room {
    
    // Room Types Enum
    public enum RoomType {
        SINGLE, DOUBLE, SUITE, DELUXE
    }
    
    // Room Status Enum
    public enum RoomStatus {
        AVAILABLE, OCCUPIED, MAINTENANCE
    }
    
    // Fields
    private int roomId;
    private String roomNumber;
    private RoomType roomType;
    private double basePrice;
    private int capacity;
    private RoomStatus status;
    private String description;
    private Timestamp createdAt;
    
    // Constructors
    public Room() {
        this.status = RoomStatus.AVAILABLE;
    }
    
    public Room(int roomId, String roomNumber, RoomType roomType, double basePrice, 
                int capacity, RoomStatus status, String description) {
        this.roomId = roomId;
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.basePrice = basePrice;
        this.capacity = capacity;
        this.status = status;
        this.description = description;
    }
    
    // Getters and Setters
    public int getRoomId() {
        return roomId;
    }
    
    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }
    
    public String getRoomNumber() {
        return roomNumber;
    }
    
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    
    public RoomType getRoomType() {
        return roomType;
    }
    
    public void setRoomType(RoomType roomType) {
        this.roomType = roomType;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
    
    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }
    
    public int getCapacity() {
        return capacity;
    }
    
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    
    public RoomStatus getStatus() {
        return status;
    }
    
    public void setStatus(RoomStatus status) {
        this.status = status;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    // Helper Methods
    public boolean isAvailable() {
        return this.status == RoomStatus.AVAILABLE;
    }
    
    public String getDisplayName() {
        return roomNumber + " - " + roomType.name();
    }
    
    @Override
    public String toString() {
        return String.format("Room[%s, %s, ₹%.2f, %s]", 
            roomNumber, roomType, basePrice, status);
    }
}
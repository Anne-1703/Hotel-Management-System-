package com.hotel.models;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * Booking Model Class
 * Represents a room booking in the system
 */
public class Booking {
    
    // Booking Status Enum
    public enum BookingStatus {
        PENDING, CONFIRMED, CHECKED_IN, CHECKED_OUT, CANCELLED
    }
    
    // Fields
    private int bookingId;
    private int customerId;
    private int roomId;
    private Date checkInDate;
    private Date checkOutDate;
    private int totalNights;
    private BookingStatus bookingStatus;
    private Timestamp bookingDate;
    
    // Additional fields for display (not in database)
    private String customerName;
    private String roomNumber;
    private String roomType;
    
    // Constructors
    public Booking() {
        this.bookingStatus = BookingStatus.PENDING;
    }
    
    public Booking(int customerId, int roomId, Date checkInDate, 
                   Date checkOutDate, int totalNights) {
        this.customerId = customerId;
        this.roomId = roomId;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.totalNights = totalNights;
        this.bookingStatus = BookingStatus.PENDING;
    }
    
    // Getters and Setters
    public int getBookingId() {
        return bookingId;
    }
    
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }
    
    public int getCustomerId() {
        return customerId;
    }
    
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    
    public int getRoomId() {
        return roomId;
    }
    
    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }
    
    public Date getCheckInDate() {
        return checkInDate;
    }
    
    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }
    
    public Date getCheckOutDate() {
        return checkOutDate;
    }
    
    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }
    
    public int getTotalNights() {
        return totalNights;
    }
    
    public void setTotalNights(int totalNights) {
        this.totalNights = totalNights;
    }
    
    public BookingStatus getBookingStatus() {
        return bookingStatus;
    }
    
    public void setBookingStatus(BookingStatus bookingStatus) {
        this.bookingStatus = bookingStatus;
    }
    
    public Timestamp getBookingDate() {
        return bookingDate;
    }
    
    public void setBookingDate(Timestamp bookingDate) {
        this.bookingDate = bookingDate;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    
    public String getRoomNumber() {
        return roomNumber;
    }
    
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    
    public String getRoomType() {
        return roomType;
    }
    
    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }
    
    // Helper Methods
    public boolean isActive() {
        return bookingStatus == BookingStatus.CONFIRMED || 
               bookingStatus == BookingStatus.CHECKED_IN;
    }
    
    public boolean canCheckIn() {
        return bookingStatus == BookingStatus.CONFIRMED;
    }
    
    public boolean canCheckOut() {
        return bookingStatus == BookingStatus.CHECKED_IN;
    }
    
    @Override
    public String toString() {
        return String.format("Booking[%d, Customer:%d, Room:%d, %s to %s, Status:%s]", 
            bookingId, customerId, roomId, checkInDate, checkOutDate, bookingStatus);
    }
}
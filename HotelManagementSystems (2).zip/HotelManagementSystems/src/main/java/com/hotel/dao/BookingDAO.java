package com.hotel.dao;

import com.hotel.config.DatabaseConfig;
import com.hotel.models.Booking;
import com.hotel.models.Booking.BookingStatus;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * BookingDAO - Data Access Object for Booking operations
 */
public class BookingDAO {
    
    /**
     * Create new booking
     */
    public boolean createBooking(Booking booking) {
        String sql = "INSERT INTO bookings (customer_id, room_id, check_in_date, check_out_date, " +
                     "total_nights, booking_status) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, booking.getCustomerId());
            pstmt.setInt(2, booking.getRoomId());
            pstmt.setDate(3, booking.getCheckInDate());
            pstmt.setDate(4, booking.getCheckOutDate());
            pstmt.setInt(5, booking.getTotalNights());
            pstmt.setString(6, booking.getBookingStatus().name());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    booking.setBookingId(rs.getInt(1));
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error creating booking: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Get booking by ID
     */
    public Booking getBookingById(int bookingId) {
        String sql = "SELECT b.*, c.full_name as customer_name, r.room_number, r.room_type " +
                     "FROM bookings b " +
                     "JOIN customers c ON b.customer_id = c.customer_id " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE b.booking_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, bookingId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractBookingFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting booking: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Get all bookings
     */
    public List<Booking> getAllBookings() {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT b.*, c.full_name as customer_name, r.room_number, r.room_type " +
                     "FROM bookings b " +
                     "JOIN customers c ON b.customer_id = c.customer_id " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "ORDER BY b.booking_date DESC";
        
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                bookings.add(extractBookingFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all bookings: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }
    
    /**
     * Get bookings by customer ID
     */
    public List<Booking> getBookingsByCustomerId(int customerId) {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT b.*, c.full_name as customer_name, r.room_number, r.room_type " +
                     "FROM bookings b " +
                     "JOIN customers c ON b.customer_id = c.customer_id " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE b.customer_id = ? " +
                     "ORDER BY b.booking_date DESC";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                bookings.add(extractBookingFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting customer bookings: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }
    
    /**
     * Get bookings by status
     */
    public List<Booking> getBookingsByStatus(BookingStatus status) {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT b.*, c.full_name as customer_name, r.room_number, r.room_type " +
                     "FROM bookings b " +
                     "JOIN customers c ON b.customer_id = c.customer_id " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE b.booking_status = ? " +
                     "ORDER BY b.check_in_date";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status.name());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                bookings.add(extractBookingFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting bookings by status: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }
    
    /**
     * Update booking status
     */
    public boolean updateBookingStatus(int bookingId, BookingStatus status) {
        String sql = "UPDATE bookings SET booking_status = ? WHERE booking_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status.name());
            pstmt.setInt(2, bookingId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating booking status: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Update booking details
     */
    public boolean updateBooking(Booking booking) {
        String sql = "UPDATE bookings SET check_in_date = ?, check_out_date = ?, " +
                     "total_nights = ?, booking_status = ? WHERE booking_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDate(1, booking.getCheckInDate());
            pstmt.setDate(2, booking.getCheckOutDate());
            pstmt.setInt(3, booking.getTotalNights());
            pstmt.setString(4, booking.getBookingStatus().name());
            pstmt.setInt(5, booking.getBookingId());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating booking: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Cancel booking
     */
    public boolean cancelBooking(int bookingId) {
        return updateBookingStatus(bookingId, BookingStatus.CANCELLED);
    }
    
    /**
     * Check room availability for dates
     */
    public boolean isRoomAvailable(int roomId, Date checkIn, Date checkOut) {
        String sql = "SELECT COUNT(*) FROM bookings " +
                     "WHERE room_id = ? " +
                     "AND booking_status IN ('CONFIRMED', 'CHECKED_IN') " +
                     "AND NOT (check_out_date <= ? OR check_in_date >= ?)";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, roomId);
            pstmt.setDate(2, checkIn);
            pstmt.setDate(3, checkOut);
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) == 0; // Available if count is 0
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking room availability: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Get today's check-ins
     */
    public List<Booking> getTodayCheckIns() {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT b.*, c.full_name as customer_name, r.room_number, r.room_type " +
                     "FROM bookings b " +
                     "JOIN customers c ON b.customer_id = c.customer_id " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE b.check_in_date = CURDATE() " +
                     "AND b.booking_status = 'CONFIRMED'";
        
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                bookings.add(extractBookingFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting today's check-ins: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }
    
    /**
     * Get today's check-outs
     */
    public List<Booking> getTodayCheckOuts() {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT b.*, c.full_name as customer_name, r.room_number, r.room_type " +
                     "FROM bookings b " +
                     "JOIN customers c ON b.customer_id = c.customer_id " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE b.check_out_date = CURDATE() " +
                     "AND b.booking_status = 'CHECKED_IN'";
        
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                bookings.add(extractBookingFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting today's check-outs: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }
    
    /**
     * Helper method to extract Booking from ResultSet
     */
    private Booking extractBookingFromResultSet(ResultSet rs) throws SQLException {
        Booking booking = new Booking();
        booking.setBookingId(rs.getInt("booking_id"));
        booking.setCustomerId(rs.getInt("customer_id"));
        booking.setRoomId(rs.getInt("room_id"));
        booking.setCheckInDate(rs.getDate("check_in_date"));
        booking.setCheckOutDate(rs.getDate("check_out_date"));
        booking.setTotalNights(rs.getInt("total_nights"));
        booking.setBookingStatus(BookingStatus.valueOf(rs.getString("booking_status")));
        booking.setBookingDate(rs.getTimestamp("booking_date"));
        
        // Additional display fields
        booking.setCustomerName(rs.getString("customer_name"));
        booking.setRoomNumber(rs.getString("room_number"));
        booking.setRoomType(rs.getString("room_type"));
        
        return booking;
    }
}
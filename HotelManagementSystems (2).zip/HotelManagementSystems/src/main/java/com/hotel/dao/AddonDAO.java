package com.hotel.dao;

import com.hotel.config.DatabaseConfig;
import com.hotel.models.Addon;
import com.hotel.models.Addon.AddonType;
import com.hotel.models.BookingAddon;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * AddonDAO - Data Access Object for Addon operations
 */
public class AddonDAO {
    
    /**
     * Get all active addons
     */
    public List<Addon> getAllAddons() {
        List<Addon> addons = new ArrayList<>();
        String sql = "SELECT * FROM addons WHERE is_active = TRUE ORDER BY addon_type, addon_name";
        
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                addons.add(extractAddonFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all addons: " + e.getMessage());
            e.printStackTrace();
        }
        
        return addons;
    }
    
    /**
     * Get addons by type
     */
    public List<Addon> getAddonsByType(AddonType type) {
        List<Addon> addons = new ArrayList<>();
        String sql = "SELECT * FROM addons WHERE addon_type = ? AND is_active = TRUE ORDER BY addon_name";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, type.name());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                addons.add(extractAddonFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting addons by type: " + e.getMessage());
            e.printStackTrace();
        }
        
        return addons;
    }
    
    /**
     * Get addon by ID
     */
    public Addon getAddonById(int addonId) {
        String sql = "SELECT * FROM addons WHERE addon_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, addonId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractAddonFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting addon: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Create new addon
     */
    public boolean createAddon(Addon addon) {
        String sql = "INSERT INTO addons (addon_name, addon_type, price, description, is_active) " +
                     "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, addon.getAddonName());
            pstmt.setString(2, addon.getAddonType().name());
            pstmt.setDouble(3, addon.getPrice());
            pstmt.setString(4, addon.getDescription());
            pstmt.setBoolean(5, addon.isActive());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    addon.setAddonId(rs.getInt(1));
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error creating addon: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Update addon
     */
    public boolean updateAddon(Addon addon) {
        String sql = "UPDATE addons SET addon_name = ?, addon_type = ?, price = ?, " +
                     "description = ?, is_active = ? WHERE addon_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, addon.getAddonName());
            pstmt.setString(2, addon.getAddonType().name());
            pstmt.setDouble(3, addon.getPrice());
            pstmt.setString(4, addon.getDescription());
            pstmt.setBoolean(5, addon.isActive());
            pstmt.setInt(6, addon.getAddonId());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating addon: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Delete addon
     */
    public boolean deleteAddon(int addonId) {
        String sql = "DELETE FROM addons WHERE addon_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, addonId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting addon: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // ============ Booking Addons Methods ============
    
    /**
     * Add addon to booking
     */
    public boolean addAddonToBooking(BookingAddon bookingAddon) {
        String sql = "INSERT INTO booking_addons (booking_id, addon_id, quantity, total_price) " +
                     "VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, bookingAddon.getBookingId());
            pstmt.setInt(2, bookingAddon.getAddonId());
            pstmt.setInt(3, bookingAddon.getQuantity());
            pstmt.setDouble(4, bookingAddon.getTotalPrice());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    bookingAddon.setBookingAddonId(rs.getInt(1));
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error adding addon to booking: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Get addons for a booking
     */
    public List<BookingAddon> getBookingAddons(int bookingId) {
        List<BookingAddon> bookingAddons = new ArrayList<>();
        String sql = "SELECT ba.*, a.addon_name, a.addon_type, a.price as unit_price " +
                     "FROM booking_addons ba " +
                     "JOIN addons a ON ba.addon_id = a.addon_id " +
                     "WHERE ba.booking_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, bookingId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                BookingAddon ba = new BookingAddon();
                ba.setBookingAddonId(rs.getInt("booking_addon_id"));
                ba.setBookingId(rs.getInt("booking_id"));
                ba.setAddonId(rs.getInt("addon_id"));
                ba.setQuantity(rs.getInt("quantity"));
                ba.setTotalPrice(rs.getDouble("total_price"));
                ba.setAddedDate(rs.getTimestamp("added_date"));
                ba.setAddonName(rs.getString("addon_name"));
                ba.setAddonType(rs.getString("addon_type"));
                ba.setUnitPrice(rs.getDouble("unit_price"));
                bookingAddons.add(ba);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting booking addons: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookingAddons;
    }
    
    /**
     * Get total addon charges for a booking
     */
    public double getTotalAddonCharges(int bookingId) {
        String sql = "SELECT COALESCE(SUM(total_price), 0) as total FROM booking_addons WHERE booking_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, bookingId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting total addon charges: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0.0;
    }
    
    /**
     * Remove addon from booking
     */
    public boolean removeBookingAddon(int bookingAddonId) {
        String sql = "DELETE FROM booking_addons WHERE booking_addon_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, bookingAddonId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error removing booking addon: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Helper method to extract Addon from ResultSet
     */
    private Addon extractAddonFromResultSet(ResultSet rs) throws SQLException {
        Addon addon = new Addon();
        addon.setAddonId(rs.getInt("addon_id"));
        addon.setAddonName(rs.getString("addon_name"));
        addon.setAddonType(AddonType.valueOf(rs.getString("addon_type")));
        addon.setPrice(rs.getDouble("price"));
        addon.setDescription(rs.getString("description"));
        addon.setActive(rs.getBoolean("is_active"));
        return addon;
    }
}
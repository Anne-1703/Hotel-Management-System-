package com.hotel.dao;

import com.hotel.config.DatabaseConfig;
import com.hotel.models.Bill;
import com.hotel.models.Bill.PaymentStatus;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * BillDAO - Data Access Object for Bill operations
 */
public class BillDAO {
    
    /**
     * Create new bill
     */
    public boolean createBill(Bill bill) {
        String sql = "INSERT INTO bills (booking_id, room_charges, addon_charges, tax_amount, " +
                     "discount_amount, total_amount, payment_status, payment_method) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, bill.getBookingId());
            pstmt.setDouble(2, bill.getRoomCharges());
            pstmt.setDouble(3, bill.getAddonCharges());
            pstmt.setDouble(4, bill.getTaxAmount());
            pstmt.setDouble(5, bill.getDiscountAmount());
            pstmt.setDouble(6, bill.getTotalAmount());
            pstmt.setString(7, bill.getPaymentStatus().name());
            pstmt.setString(8, bill.getPaymentMethod());
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    bill.setBillId(rs.getInt(1));
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error creating bill: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Get bill by ID
     */
    public Bill getBillById(int billId) {
        String sql = "SELECT b.*, bk.booking_id, c.full_name as customer_name, r.room_number " +
                     "FROM bills b " +
                     "JOIN bookings bk ON b.booking_id = bk.booking_id " +
                     "JOIN customers c ON bk.customer_id = c.customer_id " +
                     "JOIN rooms r ON bk.room_id = r.room_id " +
                     "WHERE b.bill_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, billId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractBillFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting bill: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Get bill by booking ID
     */
    public Bill getBillByBookingId(int bookingId) {
        String sql = "SELECT b.*, bk.booking_id, c.full_name as customer_name, r.room_number " +
                     "FROM bills b " +
                     "JOIN bookings bk ON b.booking_id = bk.booking_id " +
                     "JOIN customers c ON bk.customer_id = c.customer_id " +
                     "JOIN rooms r ON bk.room_id = r.room_id " +
                     "WHERE b.booking_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, bookingId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractBillFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting bill by booking: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Get all bills
     */
    public List<Bill> getAllBills() {
        List<Bill> bills = new ArrayList<>();
        String sql = "SELECT b.*, bk.booking_id, c.full_name as customer_name, r.room_number " +
                     "FROM bills b " +
                     "JOIN bookings bk ON b.booking_id = bk.booking_id " +
                     "JOIN customers c ON bk.customer_id = c.customer_id " +
                     "JOIN rooms r ON bk.room_id = r.room_id " +
                     "ORDER BY b.bill_date DESC";
        
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                bills.add(extractBillFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all bills: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bills;
    }
    
    /**
     * Get bills by payment status
     */
    public List<Bill> getBillsByStatus(PaymentStatus status) {
        List<Bill> bills = new ArrayList<>();
        String sql = "SELECT b.*, bk.booking_id, c.full_name as customer_name, r.room_number " +
                     "FROM bills b " +
                     "JOIN bookings bk ON b.booking_id = bk.booking_id " +
                     "JOIN customers c ON bk.customer_id = c.customer_id " +
                     "JOIN rooms r ON bk.room_id = r.room_id " +
                     "WHERE b.payment_status = ? " +
                     "ORDER BY b.bill_date DESC";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status.name());
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                bills.add(extractBillFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting bills by status: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bills;
    }
    
    /**
     * Update bill
     */
    public boolean updateBill(Bill bill) {
        String sql = "UPDATE bills SET room_charges = ?, addon_charges = ?, tax_amount = ?, " +
                     "discount_amount = ?, total_amount = ?, payment_status = ?, payment_method = ? " +
                     "WHERE bill_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDouble(1, bill.getRoomCharges());
            pstmt.setDouble(2, bill.getAddonCharges());
            pstmt.setDouble(3, bill.getTaxAmount());
            pstmt.setDouble(4, bill.getDiscountAmount());
            pstmt.setDouble(5, bill.getTotalAmount());
            pstmt.setString(6, bill.getPaymentStatus().name());
            pstmt.setString(7, bill.getPaymentMethod());
            pstmt.setInt(8, bill.getBillId());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating bill: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Update payment status
     */
    public boolean updatePaymentStatus(int billId, PaymentStatus status, String paymentMethod) {
        String sql = "UPDATE bills SET payment_status = ?, payment_method = ? WHERE bill_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status.name());
            pstmt.setString(2, paymentMethod);
            pstmt.setInt(3, billId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating payment status: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Get total revenue
     */
    public double getTotalRevenue() {
        String sql = "SELECT COALESCE(SUM(total_amount), 0) as total FROM bills WHERE payment_status = 'PAID'";
        
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting total revenue: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0.0;
    }
    
    /**
     * Get revenue for date range
     */
    public double getRevenueByDateRange(Date startDate, Date endDate) {
        String sql = "SELECT COALESCE(SUM(total_amount), 0) as total FROM bills " +
                     "WHERE payment_status = 'PAID' AND bill_date BETWEEN ? AND ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDate(1, startDate);
            pstmt.setDate(2, endDate);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting revenue by date range: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0.0;
    }
    
    /**
     * Get pending payments total
     */
    public double getPendingPaymentsTotal() {
        String sql = "SELECT COALESCE(SUM(total_amount), 0) as total FROM bills WHERE payment_status = 'UNPAID'";
        
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getDouble("total");
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting pending payments: " + e.getMessage());
            e.printStackTrace();
        }
        
        return 0.0;
    }
    
    /**
     * Check if bill exists for booking
     */
    public boolean billExistsForBooking(int bookingId) {
        String sql = "SELECT COUNT(*) FROM bills WHERE booking_id = ?";
        
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, bookingId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking bill existence: " + e.getMessage());
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Helper method to extract Bill from ResultSet
     */
    private Bill extractBillFromResultSet(ResultSet rs) throws SQLException {
        Bill bill = new Bill();
        bill.setBillId(rs.getInt("bill_id"));
        bill.setBookingId(rs.getInt("booking_id"));
        bill.setRoomCharges(rs.getDouble("room_charges"));
        bill.setAddonCharges(rs.getDouble("addon_charges"));
        bill.setTaxAmount(rs.getDouble("tax_amount"));
        bill.setDiscountAmount(rs.getDouble("discount_amount"));
        bill.setTotalAmount(rs.getDouble("total_amount"));
        bill.setPaymentStatus(PaymentStatus.valueOf(rs.getString("payment_status")));
        bill.setPaymentMethod(rs.getString("payment_method"));
        bill.setBillDate(rs.getTimestamp("bill_date"));
        
        // Additional display fields
        bill.setCustomerName(rs.getString("customer_name"));
        bill.setRoomNumber(rs.getString("room_number"));
        
        return bill;
    }
}
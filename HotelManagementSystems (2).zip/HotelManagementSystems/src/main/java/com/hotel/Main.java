package com.hotel;

import com.hotel.config.DatabaseConfig;
import com.hotel.ui.LoginAdminFrame;
import com.hotel.ui.LoginCustomerFrame;
import javax.swing.*;
import java.awt.*;

/**
 * Main Application Entry Point
 * Hotel Room Reservation and Billing System
 */
public class Main {
    
    public static void main(String[] args) {
        // Set look and feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Test database connection
        System.out.println("==============================================");
        System.out.println("Hotel Management System Starting...");
        System.out.println("==============================================");
        
        if (!DatabaseConfig.testConnection()) {
            JOptionPane.showMessageDialog(null,
                "Database connection failed!\n" +
                "Please ensure:\n" +
                "1. XAMPP MySQL is running\n" +
                "2. Database 'hotel_management' exists\n" +
                "3. MySQL connector JAR is in lib folder",
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        
        // Show welcome screen
        SwingUtilities.invokeLater(() -> {
            showWelcomeScreen();
        });
    }
    
    /**
     * Show welcome screen with role selection
     */
    private static void showWelcomeScreen() {
        JFrame welcomeFrame = new JFrame("Hotel Management System");
        welcomeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        welcomeFrame.setSize(500, 400);
        welcomeFrame.setLocationRelativeTo(null);
        
        // Main panel with gradient background
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(0, 0, new Color(41, 128, 185), 
                                                     0, getHeight(), new Color(109, 213, 250));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setOpaque(false);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(40, 20, 20, 20));
        
        JLabel titleLabel = new JLabel("HOTEL MANAGEMENT SYSTEM");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Room Reservation & Billing");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitleLabel.setForeground(new Color(236, 240, 241));
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        headerPanel.add(titleLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        headerPanel.add(subtitleLabel);
        
        // Center panel with buttons
        JPanel centerPanel = new JPanel();
        centerPanel.setOpaque(false);
        centerPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Customer button
        JButton customerBtn = createStyledButton("Customer Login", new Color(46, 204, 113));
        customerBtn.addActionListener(e -> {
            welcomeFrame.dispose();
            new LoginCustomerFrame().setVisible(true);
        });
        
        // Admin button
        JButton adminBtn = createStyledButton("Admin Login", new Color(231, 76, 60));
        adminBtn.addActionListener(e -> {
            welcomeFrame.dispose();
            new LoginAdminFrame().setVisible(true);
        });
        
        // Exit button
        JButton exitBtn = createStyledButton("Exit", new Color(149, 165, 166));
        exitBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(welcomeFrame,
                "Are you sure you want to exit?",
                "Confirm Exit",
                JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                DatabaseConfig.closeConnection();
                System.exit(0);
            }
        });
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        centerPanel.add(customerBtn, gbc);
        
        gbc.gridy = 1;
        centerPanel.add(adminBtn, gbc);
        
        gbc.gridy = 2;
        centerPanel.add(exitBtn, gbc);
        
        // Footer panel
        JPanel footerPanel = new JPanel();
        footerPanel.setOpaque(false);
        footerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        
        JLabel footerLabel = new JLabel("© 2025 Hotel Management System ");
        footerLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        footerLabel.setForeground(new Color(236, 240, 241));
        footerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        footerPanel.add(footerLabel);
        
        // Add components
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        welcomeFrame.add(mainPanel);
        welcomeFrame.setVisible(true);
    }
    
    /**
     * Create styled button
     */
    private static JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(250, 50));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }
}